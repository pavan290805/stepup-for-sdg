import React, { useState } from "react";
import { Sliders, Shield, Save, Key, Globe, Eye, UserCheck, HardDrive, RefreshCw } from "lucide-react";

interface SettingsProps {
  adminEmail: string;
  setAdminEmail: (email: string) => void;
}

export default function SettingsView({ adminEmail, setAdminEmail }: SettingsProps) {
  const [emailInput, setEmailInput] = useState(adminEmail);
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // General parameters config simulation
  const [isDemoMode, setIsDemoMode] = useState(true);
  const [sdgMetricsWeight, setSdgMetricsWeight] = useState(1.5);
  const [autoVerifyEmails, setAutoVerifyEmails] = useState(false);

  const handleUpdateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    setAdminEmail(emailInput);
    setSuccessMsg("System Profile updated successfully!");
    setOldPassword("");
    setNewPassword("");
    setTimeout(() => setSuccessMsg(null), 3500);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      
      {/* Success notification banner */}
      {successMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-150 text-[#4C9F38] rounded-xl text-xs font-bold text-center animate-pulse">
          {successMsg}
        </div>
      )}

      {/* Account Info settings */}
      <div className="bg-white p-6 border border-slate-200/80 rounded-2xl">
        <h3 className="font-bold font-display text-slate-905 text-sm mb-1.5 flex items-center gap-2">
          <Shield className="w-5 h-5 text-blue-600" />
          Administrative Identity & Access
        </h3>
        <p className="text-xs text-slate-500 mb-4">
          Update the primary administrative profile email domain and lock-pin passcodes.
        </p>

        <form onSubmit={handleUpdateAccount} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1">
                Liaison Contact Email
              </label>
              <input
                type="email"
                required
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-blue-500/20"
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1">
                Security Key Designation
              </label>
              <input
                type="text"
                disabled
                value="UN-SDG-SECRET-CORE-MOM-147"
                className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono text-slate-500 select-all"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1">
                Current Access Pin
              </label>
              <input
                type="password"
                placeholder="••••••••"
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-blue-500/20"
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1">
                New Replacement Access Pin
              </label>
              <input
                type="password"
                placeholder="••••••••"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-blue-500/20"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-4 py-2 bg-slate-900 hover:bg-slate-850 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors focus:outline-none cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Modify Access Credentials</span>
            </button>
          </div>
        </form>
      </div>

      {/* Global Configuration Parameters */}
      <div className="bg-white p-6 border border-slate-200/80 rounded-2xl">
        <h3 className="font-bold font-display text-slate-905 text-sm mb-1.5 flex items-center gap-2">
          <Sliders className="w-5 h-5 text-[#DDA63A]" />
          Platform Metrics & Weights Parameters
        </h3>
        <p className="text-xs text-slate-500 mb-4">
          Tune public scoring values, default coefficients, and automatic verification rules.
        </p>

        <div className="space-y-4">
          {/* Slider for metric multi */}
          <div className="space-y-1.5 bg-slate-50/50 p-4 border border-slate-200/60 rounded-xl">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-800">SDG Score Multiplier Co-efficient</span>
              <span className="font-mono text-[11px] bg-amber-50 rounded border border-amber-200 px-1.5 py-0.5 text-amber-700 font-bold">
                ×{sdgMetricsWeight.toFixed(1)} Weight Value
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Scales calculated social and green action contributions when visualizing county achievements aggregate.
            </p>
            <input
              type="range"
              min="0.5"
              max="5.0"
              step="0.5"
              value={sdgMetricsWeight}
              onChange={(e) => setSdgMetricsWeight(Number(e.target.value))}
              className="w-full accent-blue-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
            />
          </div>

          {/* Toggle Switches */}
          <div className="flex items-center justify-between p-4 bg-slate-50/50 border border-slate-200/60 rounded-xl">
            <div className="pr-4">
              <span className="block font-bold text-slate-800 text-xs">Auto-verify Registered Schools</span>
              <span className="text-[11px] text-slate-400 mt-0.5 leading-relaxed block">
                Approved local domains with government tags automatically clear review pipelines.
              </span>
            </div>
            <button
              onClick={() => setAutoVerifyEmails(!autoVerifyEmails)}
              className={`w-11 h-6 rounded-full transition-colors relative shrink-0 focus:outline-none cursor-pointer ${
                autoVerifyEmails ? "bg-[#56C02B]" : "bg-slate-305 bg-slate-300"
              }`}
            >
              <span 
                className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${
                  autoVerifyEmails ? "translate-x-6" : "translate-x-1"
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between p-4 bg-slate-50/50 border border-slate-200/60 rounded-xl">
            <div className="pr-4">
              <span className="block font-bold text-slate-800 text-xs">Acknowledge Local Demo Sandbox Mode</span>
              <span className="text-[11px] text-slate-400 mt-0.5 leading-relaxed block">
                Loads and returns instant mocked metrics to secure immediate system responsiveness testing workflows.
              </span>
            </div>
            <button
              onClick={() => setIsDemoMode(!isDemoMode)}
              className={`w-11 h-6 rounded-full transition-colors relative shrink-0 focus:outline-none cursor-pointer ${
                isDemoMode ? "bg-blue-600" : "bg-slate-300"
              }`}
            >
              <span 
                className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${
                  isDemoMode ? "translate-x-6" : "translate-x-1"
                }`}
              />
            </button>
          </div>
        </div>
      </div>

    </div>
  );
}
