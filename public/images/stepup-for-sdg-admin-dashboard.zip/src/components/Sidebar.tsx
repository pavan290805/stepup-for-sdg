import React from "react";
import { 
  LayoutDashboard, 
  Map, 
  Users, 
  ShieldCheck, 
  Mail, 
  Settings, 
  LogOut, 
  Menu, 
  X, 
  Sparkles,
  TreeDeciduous
} from "lucide-react";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  onLogout: () => void;
  pendingCount: number;
  unreadInquiries: number;
}

export default function Sidebar({ 
  activeTab, 
  setActiveTab, 
  isOpen, 
  setIsOpen, 
  onLogout,
  pendingCount,
  unreadInquiries
}: SidebarProps) {
  
  const menuItems = [
    {
      id: "dashboard",
      name: "Dashboard",
      icon: LayoutDashboard,
      badge: null
    },
    {
      id: "sdg",
      name: "SDG Management",
      icon: Map,
      badge: null
    },
    {
      id: "partner",
      name: "Partner Management",
      icon: Users,
      badge: null
    },
    {
      id: "review",
      name: "Partnership Review",
      icon: ShieldCheck,
      badge: pendingCount > 0 ? pendingCount : null,
      badgeColor: "bg-[#E5243B] text-white"
    },
    {
      id: "inquiry",
      name: "Inquiry Centre",
      icon: Mail,
      badge: unreadInquiries > 0 ? unreadInquiries : null,
      badgeColor: "bg-blue-600 text-white"
    },
    {
      id: "settings",
      name: "Settings",
      icon: Settings,
      badge: null
    }
  ];

  return (
    <>
      {/* Mobile Sidebar overlay toggles */}
      {isOpen && (
        <div 
          onClick={() => setIsOpen(false)}
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-xs lg:hidden"
        />
      )}

      {/* Main Sidebar Panel */}
      <aside 
        className={`fixed inset-y-0 left-0 z-50 flex flex-col w-68 bg-slate-900 text-slate-300 border-r border-slate-800 transition-transform duration-300 lg:translate-x-0 ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Header Branding */}
        <div className="relative flex items-center justify-between h-16 px-5 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center font-bold text-white text-base font-display shadow-md">
              S☝
            </div>
            <div>
              <span className="block font-bold font-display text-white text-sm leading-tight tracking-tight">StepUp for SDG</span>
              <span className="text-[10px] text-slate-400 font-mono tracking-wider">PORTAL_V2.0</span>
            </div>
          </div>

          <button 
            type="button"
            onClick={() => setIsOpen(false)}
            className="p-1 text-slate-400 hover:text-white rounded-lg lg:hidden"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Decorative Top Multi-Color indicator line */}
          <div className="absolute top-0 inset-x-0 h-[3px] flex">
            <div className="flex-1 bg-[#E5243B]" />
            <div className="flex-1 bg-[#DDA63A]" />
            <div className="flex-1 bg-[#4C9F38]" />
            <div className="flex-1 bg-[#26BDE2]" />
            <div className="flex-1 bg-[#FCC30B]" />
            <div className="flex-1 bg-[#3F7E44]" />
            <div className="flex-1 bg-[#56C02B]" />
          </div>
        </div>

        {/* SDG platform badge details */}
        <div className="px-4 py-3 bg-slate-950/40 border-b border-slate-850/60 flex items-center gap-2.5">
          <div className="w-2.5 h-2.5 rounded-full bg-[#56C02B] animate-ping" />
          <div className="text-xs">
            <span className="text-slate-400">Status: </span>
            <span className="font-semibold text-slate-200">UN Core Liaison Active</span>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
          {menuItems.map((item) => {
            const IconComponent = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsOpen(false); // Close sidebar on mobile select
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium transition-all group ${
                  isActive 
                    ? "bg-white/5 text-white border-l-4 border-blue-500 rounded-r-lg font-bold -ml-3 pl-2" 
                    : "text-slate-400 hover:text-white hover:bg-slate-800/40 border-l-4 border-transparent"
                }`}
              >
                <div className="flex items-center gap-3">
                  <IconComponent className={`w-4.5 h-4.5 shrink-0 ${
                    isActive ? "text-white" : "text-slate-400 group-hover:text-blue-400"
                  }`} />
                  <span>{item.name}</span>
                </div>

                {item.badge !== null && (
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${item.badgeColor || "bg-slate-800 text-slate-200"}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Logged In Info / Quick Panel config */}
        <div className="p-4 mx-3 my-3 rounded-xl bg-slate-950/50 border border-slate-800/80">
          <div className="flex items-center gap-2.5 mb-2">
            <div className="w-7 h-7 rounded-full bg-blue-500/10 border border-blue-500/25 flex items-center justify-center font-display text-[#26BDE2] text-xs font-semibold">
              UN
            </div>
            <div className="text-left leading-tight">
              <span className="block text-xs font-semibold text-slate-200">SDG National Sec</span>
              <span className="text-[10px] text-slate-500">Government Liaison</span>
            </div>
          </div>
          <div className="text-[10px] text-slate-400 leading-relaxed">
            Authorized for SDG evaluation, partner auditing, and event management operations under NGO-M-1473.
          </div>
        </div>

        {/* Logout Section at the static bottom */}
        <div className="p-4 border-t border-slate-800 mt-auto">
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-colors group"
          >
            <LogOut className="w-4.5 h-4.5 shrink-0 text-red-400 group-hover:translate-x-1 transition-transform" />
            <span>Terminate Session</span>
          </button>
        </div>
      </aside>
    </>
  );
}
