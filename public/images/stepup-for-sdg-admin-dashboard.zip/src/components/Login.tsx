import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Mail, Lock, Eye, EyeOff, TreeDeciduous, Quote, Info, CheckCircle2, Globe, Award, ShieldAlert, User, Sparkles } from "lucide-react";

interface LoginProps {
  onLoginSuccess: (email: string) => void;
}

export default function Login({ onLoginSuccess }: LoginProps) {
  const [email, setEmail] = useState("admin@stepup.org");
  const [password, setPassword] = useState("admin1234");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [forgotSent, setForgotSent] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [isForgotOpen, setIsForgotOpen] = useState(false);

  // Sign Up Mode States
  const [isSignUp, setIsSignUp] = useState(false);
  const [signUpName, setSignUpName] = useState("");
  const [signUpEmail, setSignUpEmail] = useState("");
  const [signUpPassword, setSignUpPassword] = useState("");
  const [signUpConfirmPassword, setSignUpConfirmPassword] = useState("");
  const [signUpSuccess, setSignUpSuccess] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const colors = [
      "#E5243B", // Red (Goal 1)
      "#DDA63A", // Yellow/Amber (Goal 7)
      "#4C9F38", // Green (Goal 3)
      "#C5192D", // Dark Red (Goal 4)
      "#26BDE2", // Sky Blue (Goal 6)
      "#FCC30B", // Bright Yellow (Goal 7)
      "#3F7E44", // Forest Green (Goal 13)
      "#10b981", // Emerald Green 
      "#3b82f6", // Royal Blue 
      "#ec4899", // Pink (Goal 5)
    ];

    interface Particle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      radius: number;
      color: string;
      alpha: number;
      angle: number;
      speedMultiplier: number;
    }

    const particles: Particle[] = [];
    const particleCount = Math.min(80, Math.floor((width * height) / 18000));

    // Create initial particle directory
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.8,
        vy: (Math.random() - 0.5) * 0.8,
        radius: Math.random() * 2.8 + 1.2,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: Math.random() * 0.5 + 0.3,
        angle: Math.random() * Math.PI * 2,
        speedMultiplier: Math.random() * 0.4 + 0.8,
      });
    }

    interface InteractiveExplosion {
      x: number;
      y: number;
      radius: number;
      maxRadius: number;
      alpha: number;
      color: string;
    }

    let explosions: InteractiveExplosion[] = [];

    // Mouse tracking vectors
    const mouse = {
      x: null as number | null,
      y: null as number | null,
    };

    const handleMouseMove = (e: MouseEvent) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    };

    const handleMouseLeave = () => {
      mouse.x = null;
      mouse.y = null;
    };

    const handleCanvasClick = (e: MouseEvent) => {
      const clickX = e.clientX;
      const clickY = e.clientY;

      // Spawn colorful structural shockwave
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      explosions.push({
        x: clickX,
        y: clickY,
        radius: 2,
        maxRadius: Math.random() * 60 + 75,
        alpha: 1.0,
        color: randomColor,
      });

      // Spawn rapid burst of target objective points
      for (let i = 0; i < 12; i++) {
        const speed = Math.random() * 5 + 1.5;
        const angle = Math.random() * Math.PI * 2;
        particles.push({
          x: clickX,
          y: clickY,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          radius: Math.random() * 2.2 + 1,
          color: colors[Math.floor(Math.random() * colors.length)],
          alpha: 1.0,
          angle: Math.random() * Math.PI * 2,
          speedMultiplier: 1.1,
        });
      }

      // Hard cap particles array to support extreme continuous performance
      if (particles.length > 250) {
        particles.splice(0, particles.length - 250);
      }
    };

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseleave", handleMouseLeave);
    window.addEventListener("click", handleCanvasClick);
    window.addEventListener("resize", handleResize);

    const animate = () => {
      ctx.clearRect(0, 0, width, height);

      // Render gradient background
      const gradient = ctx.createLinearGradient(0, 0, width, height);
      gradient.addColorStop(0, "#080b11");
      gradient.addColorStop(0.5, "#0f172a");
      gradient.addColorStop(1, "#03060a");
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);

      // Subtle network blueprint grid mapping
      ctx.strokeStyle = "rgba(56, 189, 248, 0.04)";
      ctx.lineWidth = 1;
      const gridSize = 80;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Render explosions
      explosions = explosions.filter((exp) => {
        exp.radius += (exp.maxRadius - exp.radius) * 0.1;
        exp.alpha -= 0.015;
        if (exp.alpha <= 0) return false;

        ctx.strokeStyle = exp.color;
        ctx.lineWidth = 2.5;
        ctx.globalAlpha = exp.alpha * 0.5;
        ctx.beginPath();
        ctx.arc(exp.x, exp.y, exp.radius, 0, Math.PI * 2);
        ctx.stroke();

        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(exp.x, exp.y, exp.radius * 0.5, 0, Math.PI * 2);
        ctx.stroke();

        ctx.globalAlpha = 1.0;
        return true;
      });

      // Gravity pull toward mouse vector (smooth)
      if (mouse.x !== null && mouse.y !== null) {
        particles.forEach((p) => {
          const dx = mouse.x! - p.x;
          const dy = mouse.y! - p.y;
          const dist = Math.hypot(dx, dy);
          if (dist < 220) {
            const force = (220 - dist) / 220;
            const angle = Math.atan2(dy, dx);
            p.vx += Math.cos(angle) * force * 0.07;
            p.vy += Math.sin(angle) * force * 0.07;
          }
        });
      }

      // Update & render particles
      particles.forEach((p, idx) => {
        p.x += p.vx * p.speedMultiplier;
        p.y += p.vy * p.speedMultiplier;

        // Subtle fluid drag to stabilize velocities over time
        p.vx *= 0.985;
        p.vy *= 0.985;

        // Floating sinusoidal wave motion
        p.angle += 0.015;
        p.y += Math.sin(p.angle) * 0.1;

        // Check boundaries
        if (p.x < -10) p.x = width + 10;
        if (p.x > width + 10) p.x = -10;
        if (p.y < -10) p.y = height + 10;
        if (p.y > height + 10) p.y = -10;

        // Draw particle
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();

        // Neon aura glow
        if (p.radius > 2.0) {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius * 2.5, 0, Math.PI * 2);
          ctx.globalAlpha = p.alpha * 0.15;
          ctx.fill();
        }

        // Draw links between nearby particles
        for (let j = idx + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dist = Math.hypot(p.x - p2.x, p.y - p2.y);
          if (dist < 130) {
            const linkAlpha = ((130 - dist) / 130) * 0.22;
            ctx.strokeStyle = p.color;
            ctx.globalAlpha = linkAlpha;
            ctx.lineWidth = 0.7;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        }

        // Mouse connection ray
        if (mouse.x !== null && mouse.y !== null) {
          const mDist = Math.hypot(p.x - mouse.x, p.y - mouse.y);
          if (mDist < 160) {
            const rayAlpha = ((160 - mDist) / 160) * 0.35;
            ctx.strokeStyle = p.color;
            ctx.globalAlpha = rayAlpha;
            ctx.lineWidth = 1.1;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(mouse.x, mouse.y);
            ctx.stroke();
          }
        }
      });

      ctx.globalAlpha = 1.0;
      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseleave", handleMouseLeave);
      window.removeEventListener("click", handleCanvasClick);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    setTimeout(() => {
      if (!email.trim() || !password.trim()) {
        setError("Please fill in both email and password fields.");
        setLoading(false);
        return;
      }

      // Check if there's a custom registered account
      const storedUserRaw = localStorage.getItem("stepup_custom_user");
      let customUser = null;
      if (storedUserRaw) {
        try {
          customUser = JSON.parse(storedUserRaw);
        } catch (err) {
          // Ignore
        }
      }

      if (email === "admin@stepup.org" && password === "admin1234") {
        if (rememberMe) {
          localStorage.setItem("stepup_admin_session", email);
        }
        onLoginSuccess(email);
      } else if (customUser && email.toLowerCase() === customUser.email.toLowerCase() && password === customUser.password) {
        if (rememberMe) {
          localStorage.setItem("stepup_admin_session", email);
        }
        onLoginSuccess(email);
      } else {
        setError("Invalid email address or passcode. Try 'admin@stepup.org' with 'admin1234' or create a new account below.");
        setLoading(false);
      }
    }, 750);
  };

  const handleSignUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!signUpName.trim() || !signUpEmail.trim() || !signUpPassword.trim() || !signUpConfirmPassword.trim()) {
      setError("Please fill in all register credentials.");
      return;
    }

    if (signUpPassword !== signUpConfirmPassword) {
      setError("Passcodes do not match. Please verify.");
      return;
    }

    if (signUpPassword.length < 5) {
      setError("For security, passcodes must be at least 5 characters.");
      return;
    }

    setLoading(true);

    setTimeout(() => {
      // Persist locally
      localStorage.setItem("stepup_custom_user", JSON.stringify({
        name: signUpName,
        email: signUpEmail,
        password: signUpPassword
      }));

      setSignUpSuccess(true);
      setLoading(false);

      // Auto login
      setTimeout(() => {
        onLoginSuccess(signUpEmail);
      }, 1500);
    }, 1200);
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) return;
    setForgotSent(true);
    setTimeout(() => {
      setIsForgotOpen(false);
      setForgotSent(false);
      setForgotEmail("");
    }, 3000);
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center font-sans relative overflow-hidden">
      
      {/* High performance fully interactive background canvas */}
      <canvas 
        ref={canvasRef} 
        className="absolute inset-0 z-0 w-full h-full pointer-events-auto" 
        style={{ touchAction: "none" }}
      />

      {/* Login Main Container */}
      <div className="container relative z-10 max-w-5xl mx-auto px-4 py-8">
        <div className="bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl overflow-hidden border border-slate-200 grid md:grid-cols-12 min-h-[600px] transition-all hover:shadow-[0_20px_50px_rgba(0,0,0,0.35)]">
          
          {/* Left Panel: Information and Impact Summary */}
          <div className="md:col-span-6 bg-slate-50 p-8 md:p-10 flex flex-col justify-between relative overflow-hidden border-r border-slate-150">
            {/* Subtle decorative subtle code/grid */}
            <div className="absolute inset-0 opacity-[0.05] bg-[radial-gradient(#000000_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />
            
            <div className="relative z-10 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-blue-50 border border-blue-100/80 text-blue-700 font-semibold text-xs">
                <Globe className="w-3.5 h-3.5 text-blue-600 animate-spin-slow" />
                <span>UN-SDG Monitoring Hub</span>
              </div>

              <div className="space-y-2">
                <h1 className="text-2xl font-bold tracking-tight text-slate-900 leading-tight">
                  StepUp SDG Portal
                </h1>
                <p className="text-slate-600 text-xs leading-relaxed max-w-sm font-normal">
                  Tracking and aligning local actions to the UN Sustainable Development Goals.
                </p>
              </div>

              {/* Generated Image Showcase */}
              <div className="relative aspect-square w-full max-w-[280px] mx-auto rounded-xl overflow-hidden border border-slate-200 shadow-lg bg-white">
                <img 
                  src="/src/assets/images/sdg_illustration_1781192627956.jpg" 
                  alt="UN SDG Illustration" 
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <div className="relative z-10 pt-4 border-t border-slate-200 text-[11px] text-slate-500 text-center leading-relaxed font-semibold">
              Authorized Liaison Coordinate System
            </div>
          </div>

          {/* Right Panel: Sleek, high-contrast, professional admin login / signup */}
          <div className="md:col-span-6 p-8 md:p-12 flex flex-col justify-center bg-white">
            
            <div className="w-full max-w-sm mx-auto">
              <AnimatePresence mode="wait">
                {signUpSuccess ? (
                  <motion.div
                    key="signup-success"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="text-center py-8 space-y-4"
                  >
                    <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-md">
                      <Sparkles className="w-8 h-8 animate-pulse" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="text-lg font-bold text-slate-900">Coordination Account Ready</h3>
                      <p className="text-xs text-slate-500 font-medium">
                        Your custom administrator credentials have been stored successfully.
                      </p>
                    </div>
                    <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-lg text-emerald-800 text-[11px] font-semibold inline-flex items-center gap-2">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-ping" />
                      Initializing central metrics workspace...
                    </div>
                  </motion.div>
                ) : isSignUp ? (
                  <motion.div
                    key="signup-form"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.25 }}
                    className="space-y-5"
                  >
                    <div className="space-y-1.5">
                      <div className="w-10 h-10 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-extrabold text-lg shadow-sm">
                        R
                      </div>
                      <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                        Register Liaison Account
                      </h2>
                      <p className="text-xs text-slate-500 font-medium">
                        Create new administrative coordinates for local SDG tracking
                      </p>
                    </div>

                    <form onSubmit={handleSignUpSubmit} className="space-y-3.5 pt-1">
                      {error && (
                        <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs text-left font-semibold">
                          {error}
                        </div>
                      )}

                      {/* Full Name field */}
                      <div className="space-y-1">
                        <label className="block text-[10px] uppercase font-bold text-slate-550 tracking-wider font-semibold">
                          Full Name / Organization
                        </label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <User className="w-4 h-4" />
                          </div>
                          <input
                            type="text"
                            required
                            value={signUpName}
                            onChange={(e) => setSignUpName(e.target.value)}
                            placeholder="e.g. Jane Doe"
                            className="w-full pl-9 pr-4 py-1.5 border border-[#e2e8f0] rounded-lg text-slate-950 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all bg-slate-50/50"
                          />
                        </div>
                      </div>

                      {/* Register Email field */}
                      <div className="space-y-1">
                        <label className="block text-[10px] uppercase font-bold text-slate-550 tracking-wider font-semibold">
                          Administrative Email
                        </label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <Mail className="w-4 h-4" />
                          </div>
                          <input
                            type="email"
                            required
                            value={signUpEmail}
                            onChange={(e) => setSignUpEmail(e.target.value)}
                            placeholder="jane@stepup.org"
                            className="w-full pl-9 pr-4 py-1.5 border border-[#e2e8f0] rounded-lg text-slate-950 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all bg-slate-50/50"
                          />
                        </div>
                      </div>

                      {/* Passcode field */}
                      <div className="space-y-1">
                        <label className="block text-[10px] uppercase font-bold text-slate-555 tracking-wider font-semibold">
                          Passcode (Min 5 chars)
                        </label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <Lock className="w-4 h-4" />
                          </div>
                          <input
                            type="password"
                            required
                            value={signUpPassword}
                            onChange={(e) => setSignUpPassword(e.target.value)}
                            placeholder="••••••••"
                            className="w-full pl-9 pr-4 py-1.5 border border-[#e2e8f0] rounded-lg text-slate-950 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all bg-slate-50/50"
                          />
                        </div>
                      </div>

                      {/* Confirm Passcode field */}
                      <div className="space-y-1">
                        <label className="block text-[10px] uppercase font-bold text-slate-555 tracking-wider font-semibold">
                          Confirm Passcode
                        </label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <Lock className="w-4 h-4" />
                          </div>
                          <input
                            type="password"
                            required
                            value={signUpConfirmPassword}
                            onChange={(e) => setSignUpConfirmPassword(e.target.value)}
                            placeholder="••••••••"
                            className="w-full pl-9 pr-4 py-1.5 border border-[#e2e8f0] rounded-lg text-slate-950 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-[500]/20 focus:border-emerald-500 transition-all bg-slate-50/50"
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={loading}
                        className="w-full mt-2 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-lg shadow-md transition-all active:translate-y-[0.5px] disabled:opacity-50 disabled:cursor-not-allowed flex justify-center items-center gap-2"
                      >
                        {loading ? (
                          <>
                            <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                            </svg>
                            <span>Creating Credentials...</span>
                          </>
                        ) : (
                          <span>Create Administrator Account</span>
                        )}
                      </button>
                    </form>

                    <div className="text-center pt-3 border-t border-slate-100 text-[11px] text-slate-500 font-medium">
                      Already have an administrative account?{" "}
                      <button
                        onClick={() => {
                          setIsSignUp(false);
                          setError(null);
                        }}
                        className="text-blue-600 hover:text-blue-700 hover:underline font-bold ml-1 bg-transparent border-0 cursor-pointer"
                      >
                        Sign In
                      </button>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="login-form"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.25 }}
                    className="space-y-6"
                  >
                    <div className="space-y-2">
                      <div className="w-10 h-10 rounded-lg bg-blue-600 text-white flex items-center justify-center font-extrabold text-lg shadow-sm">
                        S
                      </div>
                      <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                        Sign in to Administrator Portal
                      </h2>
                      <p className="text-xs text-slate-500 font-medium">
                        Provide authorized liaison credentials to coordinate metrics
                      </p>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-4 pt-2">
                      {error && (
                        <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs text-left font-semibold">
                          {error}
                        </div>
                      )}

                      {/* Email address field */}
                      <div className="space-y-1.5">
                        <label className="block text-[10px] uppercase font-bold text-slate-455 tracking-wider font-semibold">
                          Administrative Email
                        </label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <Mail className="w-4 h-4" />
                          </div>
                          <input
                            type="email"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="admin@stepup.org"
                            className="w-full pl-9 pr-4 py-2 border border-[#e2e8f0] rounded-lg text-slate-950 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all bg-slate-50/50"
                          />
                        </div>
                      </div>

                      {/* Password / Pin field */}
                      <div className="space-y-1.5">
                        <div className="flex justify-between items-center">
                          <label className="block text-[10px] uppercase font-bold text-slate-455 tracking-wider font-semibold">
                            Administrative Passcode
                          </label>
                          <button
                            type="button"
                            onClick={() => setIsForgotOpen(true)}
                            className="text-[11px] text-blue-600 font-bold hover:text-blue-700 hover:underline focus:outline-none bg-transparent border-0 cursor-pointer"
                          >
                            Retrieve Passcode
                          </button>
                        </div>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <Lock className="w-4 h-4" />
                          </div>
                          <input
                            type={showPassword ? "text" : "password"}
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="••••••••"
                            className="w-full pl-9 pr-10 py-2 border border-[#e2e8f0] rounded-lg text-slate-950 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all bg-slate-50/50"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-450 hover:text-slate-650 transition-colors focus:outline-none bg-transparent border-0 cursor-pointer"
                          >
                            {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>

                      {/* Remember checklist toggle */}
                      <div className="flex items-center justify-between pt-1">
                        <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-600 font-semibold select-none">
                          <input
                            type="checkbox"
                            checked={rememberMe}
                            onChange={(e) => setRememberMe(e.target.checked)}
                            className="rounded text-blue-600 border-slate-300 focus:ring-blue-500/40 bg-white w-4 h-4"
                          />
                          Save my sign-in session
                        </label>
                      </div>

                      {/* Action button */}
                      <button
                        type="submit"
                        disabled={loading}
                        className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider rounded-lg shadow-md transition-all active:translate-y-[0.5px] disabled:opacity-50 disabled:cursor-not-allowed flex justify-center items-center gap-2"
                      >
                        {loading ? (
                          <>
                            <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                            </svg>
                            <span>Signing in...</span>
                          </>
                        ) : (
                          <span>Sign In</span>
                        )}
                      </button>
                    </form>

                    <div className="text-center pt-4 border-t border-slate-100 text-[11px] text-slate-500 font-medium font-semibold">
                      New to StepUp SDG?{" "}
                      <button
                        onClick={() => {
                          setIsSignUp(true);
                          setError(null);
                        }}
                        className="text-emerald-600 hover:text-emerald-700 hover:underline font-bold ml-1 bg-transparent border-0 cursor-pointer"
                      >
                        Register Account
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Background SDG Network Tip Badge */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 pointer-events-none px-4 w-full max-w-md text-center">
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.6 }}
          className="bg-slate-950/80 backdrop-blur-md border border-slate-800/60 px-4.5 py-2.5 rounded-full shadow-xl inline-flex items-center gap-2.5 text-[11px] text-slate-200"
        >
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span>
            💡 <strong className="text-white font-bold">Interactive Sky:</strong> Move your mouse cursor or click anywhere to trigger glowing SDG constellate links!
          </span>
        </motion.div>
      </div>

      {/* Retrieve Passcode Modal Dialog */}
      <AnimatePresence>
        {isForgotOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-xl p-6 max-w-sm w-full border border-slate-200 text-slate-800 relative shadow-2xl"
            >
              <h3 className="text-base font-bold text-slate-900 mb-2">Reset Passcode</h3>
              <p className="text-xs text-slate-500 mb-4 leading-relaxed font-semibold">
                Enter your administrative email address. A bypass credential recovery token will be direct-dispatched after administrative network validation checks.
              </p>

              {forgotSent ? (
                <div className="text-center py-4 text-emerald-600">
                  <CheckCircle2 className="w-12 h-12 mx-auto mb-2 text-emerald-500" />
                  <p className="text-xs font-bold uppercase tracking-wider text-emerald-800">Recovery Token Dispatched!</p>
                  <p className="text-xs text-slate-500 mt-1 font-semibold">Please inspect your authorized local mail relays.</p>
                </div>
              ) : (
                <form onSubmit={handleForgotPassword} className="space-y-3">
                  <input
                    type="email"
                    required
                    placeholder="e.g. admin@stepup.org"
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    className="w-full px-3 py-1.5 border border-[#e2e8f0] bg-slate-50 rounded-lg text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsForgotOpen(false)}
                      className="px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-slate-100 text-slate-500 bg-transparent border-0 cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 rounded-lg text-xs bg-blue-600 hover:bg-blue-500 text-white font-bold cursor-pointer transition-all border-0 shadow-sm"
                    >
                      Dispatch Email
                    </button>
                  </div>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
