import React, { useState } from "react";
import { ReviewRequest, SDG } from "../types";
import { 
  ShieldCheck, 
  Clock, 
  XOctagon, 
  CheckCircle, 
  FileText, 
  ExternalLink,
  ChevronRight, 
  X, 
  Award, 
  AlertCircle,
  Undo
} from "lucide-react";

interface ReviewCenterViewProps {
  requests: ReviewRequest[];
  sdgs: SDG[];
  onApprove: (id: string, remarks?: string) => void;
  onDecline: (id: string, reason: string) => void;
}

export default function ReviewCenterView({
  requests,
  sdgs,
  onApprove,
  onDecline
}: ReviewCenterViewProps) {
  
  const [filterStatus, setFilterStatus] = useState<"all" | "pending" | "approved" | "declined">("all");
  const [selectedRequest, setSelectedRequest] = useState<ReviewRequest | null>(null);
  
  // Interactive action state inside modal inspector
  const [remarksInput, setRemarksInput] = useState("");
  const [showDeclineReason, setShowDeclineReason] = useState(false);
  const [declineReasonText, setDeclineReasonText] = useState("");

  // Checkbox state for validating submitted papers
  const [verifiedDocuments, setVerifiedDocuments] = useState<Record<string, boolean>>({});

  const filteredRequests = requests.filter((r) => {
    if (filterStatus === "all") return true;
    return r.status === filterStatus;
  });

  const handleOpenInspector = (req: ReviewRequest) => {
    setSelectedRequest(req);
    // Preset checklist
    const initialDocs: Record<string, boolean> = {};
    req.documents.forEach((doc, i) => {
      initialDocs[`doc-${i}`] = doc.verified;
    });
    setVerifiedDocuments(initialDocs);
    setRemarksInput(req.remarks || "");
    setShowDeclineReason(false);
    setDeclineReasonText("");
  };

  const handleToggleDocCheck = (key: string) => {
    setVerifiedDocuments(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const executeApproval = (id: string) => {
    onApprove(id, remarksInput.trim() || undefined);
    setSelectedRequest(null);
  };

  const executeDecline = (id: string) => {
    if (!declineReasonText.trim()) {
      setShowDeclineReason(true);
      return;
    }
    onDecline(id, declineReasonText.trim());
    setSelectedRequest(null);
  };

  return (
    <div className="space-y-6">
      
      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 border border-slate-200/80 rounded-xl flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-[#DDA63A] flex items-center justify-center font-bold">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] text-slate-400 uppercase font-bold tracking-wider">Awaiting Audit</span>
            <span className="text-lg font-bold text-slate-800">
              {requests.filter(r => r.status === "pending").length} applications
            </span>
          </div>
        </div>

        <div className="bg-white p-4 border border-slate-200/80 rounded-xl flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-[#4C9F38] flex items-center justify-center font-bold">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] text-slate-400 uppercase font-bold tracking-wider">Approved Partners</span>
            <span className="text-lg font-bold text-slate-800">
              {requests.filter(r => r.status === "approved").length} verified NGO/Corp
            </span>
          </div>
        </div>

        <div className="bg-white p-4 border border-slate-200/80 rounded-xl flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-red-50 text-[#C5192D] flex items-center justify-center font-bold">
            <XOctagon className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] text-slate-400 uppercase font-bold tracking-wider">Security Declined</span>
            <span className="text-lg font-bold text-slate-800">
              {requests.filter(r => r.status === "declined").length} archived
            </span>
          </div>
        </div>
      </div>

      {/* Review Queue Tab Filters */}
      <div className="bg-white p-4 border border-slate-200/80 rounded-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 flex-wrap gap-3">
          <div className="flex p-1 bg-slate-100 rounded-lg">
            {[
              { id: "all", label: "All Submissions" },
              { id: "pending", label: "Pending Audit" },
              { id: "approved", label: "Authorized Profiles" },
              { id: "declined", label: "Declined Registry" }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFilterStatus(tab.id as any)}
                className={`px-3 py-1.5 text-xs font-bold rounded-md transition-colors cursor-pointer ${
                  filterStatus === tab.id 
                    ? "bg-white text-slate-900 shadow-xs" 
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <span className="text-xs text-slate-450 font-bold font-mono">
            Queue Count: {filteredRequests.length} rows loaded
          </span>
        </div>

        {/* Evaluation Queue Table */}
        {filteredRequests.length === 0 ? (
          <div className="py-16 text-center text-slate-400 text-xs font-semibold">
            No application submissions found matching active status filters.
          </div>
        ) : (
          <div className="overflow-x-auto mt-4">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                  <th className="py-2.5 px-3">Applicant Entity</th>
                  <th className="py-2.5 px-3">Class Sector</th>
                  <th className="py-2.5 px-3">Submission Date</th>
                  <th className="py-2.5 px-3">Target SDG Chapters</th>
                  <th className="py-2.5 px-3">Status Badge</th>
                  <th className="py-2.5 px-3 text-right">Audit Workspace</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredRequests.map((req) => (
                  <tr key={req.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-3 px-3 font-bold text-slate-800 flex items-center gap-2.5">
                      <img 
                        src={req.logoUrl} 
                        alt={req.partnerName} 
                        className="w-7 h-7 rounded-lg object-cover border border-slate-205 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="text-left leading-tight">
                        <span className="block font-bold text-slate-850">{req.partnerName}</span>
                        <span className="text-[10px] text-slate-400 font-medium truncate">{req.website}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 uppercase text-[9px] font-bold">
                      <span className={`px-2 py-0.5 rounded-full ${
                        req.category === "school" ? "bg-amber-105 text-amber-700 bg-amber-50" :
                        req.category === "ngo" ? "bg-green-105 text-green-700 bg-green-50" :
                        "bg-purple-105 text-purple-700 bg-purple-50"
                      }`}>
                        {req.category}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-500 font-medium">{req.requestedAt}</td>
                    <td className="py-3 px-3">
                      <div className="flex gap-1 flex-wrap">
                        {req.appliedSDGs.map((id) => {
                          const goal = sdgs.find(s => s.id === id);
                          return (
                            <span 
                              key={id} 
                              className="px-1.5 py-0.5 rounded text-[8px] font-bold text-white shadow-xs"
                              style={{ backgroundColor: goal?.color || "#56C02B" }}
                              title={goal?.name}
                            >
                              Goal {id}
                            </span>
                          );
                        })}
                      </div>
                    </td>
                    <td className="py-3 px-3 uppercase text-[9px] font-bold">
                      <span className={`px-2 py-0.5 rounded-full ${
                        req.status === "approved" ? "bg-emerald-50 text-[#4C9F38] border border-emerald-100" :
                        req.status === "declined" ? "bg-red-50 text-[#C5192D] border border-red-100" :
                        "bg-[#FFF7E6] text-[#DDA63A] border border-[#FFE7B8]"
                      }`}>
                        {req.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => handleOpenInspector(req)}
                        className="px-2.5 py-1 font-bold text-blue-600 hover:text-white border border-blue-600/30 hover:bg-blue-600 rounded-lg transition-colors cursor-pointer"
                      >
                        Inspect Audit
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal Inspector Area */}
      {selectedRequest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl w-full max-w-2xl border border-slate-200 shadow-2xl overflow-hidden text-left animate-in fade-in zoom-in duration-200">
            
            {/* Top Multi-Color Ribbon */}
            <div className="absolute top-0 inset-x-0 h-1 flex">
              <div className="flex-1 bg-red-500" />
              <div className="flex-1 bg-amber-500" />
              <div className="flex-1 bg-emerald-500" />
              <div className="flex-1 bg-blue-500" />
            </div>

            <div className="p-6 space-y-4">
              
              {/* Header block within inspector */}
              <div className="flex justify-between items-start pb-3 border-b border-slate-100">
                <div className="flex gap-3">
                  <img
                    src={selectedRequest.logoUrl}
                    alt={selectedRequest.partnerName}
                    className="w-12 h-12 rounded-xl object-cover border border-slate-205"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h3 className="font-bold font-display text-slate-900 text-sm leading-tight">
                      Evaluating: {selectedRequest.partnerName}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
                      <span className="font-bold text-slate-500">{selectedRequest.category.toUpperCase()}</span>
                      <span>•</span>
                      <span>Submitted: {selectedRequest.requestedAt}</span>
                    </p>
                  </div>
                </div>

                <button 
                  onClick={() => setSelectedRequest(null)}
                  className="p-1 hover:bg-slate-100 rounded text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4.5 h-4.5" />
                </button>
              </div>

              {/* Grid: Application Details description & Checklist */}
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-5 py-2">
                
                {/* Left pane: Details bio summary */}
                <div className="sm:col-span-7 space-y-3">
                  <div>
                    <span className="block text-[9px] font-bold text-slate-450 uppercase tracking-wider mb-0.5">
                      Registry Objectives Statement
                    </span>
                    <p className="text-xs text-slate-650 bg-slate-50 p-3 rounded-lg leading-relaxed font-semibold border border-slate-100 whitespace-pre-line">
                      {selectedRequest.details}
                    </p>
                  </div>

                  <div>
                    <span className="block text-[9px] font-bold text-slate-455 uppercase tracking-wider mb-1">
                      Applicant Action SDG Targets
                    </span>
                    <div className="flex gap-1 px-1.5 flex-wrap">
                      {selectedRequest.appliedSDGs.map((id) => {
                        const s_obj = sdgs.find(s => s.id === id);
                        return (
                          <span 
                            key={id} 
                            style={{ backgroundColor: s_obj?.color }} 
                            className="px-2 py-0.5 rounded font-mono font-bold text-white text-[10px]"
                          >
                            SDG {id}: {s_obj?.name}
                          </span>
                        );
                      })}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="block text-[9px] text-slate-400 uppercase font-bold">Mail Domain</span>
                      <span className="font-semibold text-slate-700 truncate block">{selectedRequest.email}</span>
                    </div>
                    <div>
                      <span className="block text-[9px] text-slate-400 uppercase font-bold">Website Address</span>
                      <a 
                        href={selectedRequest.website} 
                        target="_blank" 
                        rel="noreferrer" 
                        className="font-bold text-blue-600 hover:underline flex items-center gap-0.5"
                      >
                        <span>{selectedRequest.website.replace("https://", "")}</span>
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    </div>
                  </div>
                </div>

                {/* Right pane: Papers checklists */}
                <div className="sm:col-span-5 bg-slate-50/50 p-4 border border-slate-150 rounded-xl flex flex-col justify-between">
                  <div>
                    <span className="block text-[10px] font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                      <Award className="w-4 h-4 text-blue-600" />
                      Documents Verification Checklist
                    </span>

                    <div className="space-y-2">
                      {selectedRequest.documents.map((doc, idx) => {
                        const docKey = `doc-${idx}`;
                        const isDocVerified = !!verifiedDocuments[docKey];
                        return (
                          <label 
                            key={idx} 
                            className="flex items-start gap-2.5 p-2 bg-white rounded-lg border border-slate-200 select-none cursor-pointer hover:border-blue-400/50 transition-colors"
                          >
                            <input
                              type="checkbox"
                              checked={isDocVerified}
                              onChange={() => handleToggleDocCheck(docKey)}
                              disabled={selectedRequest.status !== "pending"}
                              className="rounded text-blue-600 bg-white border-slate-300 focus:ring-blue-500 w-3.5 h-3.5 mt-0.5"
                            />
                            <div className="leading-tight">
                              <span className="block font-bold text-[10px] text-slate-800 line-clamp-1">{doc.label}</span>
                              <span className="text-[8px] text-blue-600 font-bold hover:underline">Download / Open PDF</span>
                            </div>
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  {selectedRequest.status === "pending" && (
                    <div className="mt-4 p-2.5 rounded bg-blue-50 border border-blue-100 flex gap-2 text-[10px] text-blue-800 font-medium">
                      <AlertCircle className="w-4 h-4 shrink-0 text-blue-600" />
                      <span>Check the boxes to stamp validation security onto legal board papers.</span>
                    </div>
                  )}
                </div>

              </div>

              {/* Status actions / Remarks input footer */}
              <div className="pt-4 border-t border-slate-100 space-y-4">
                
                {/* Remarks textarea */}
                {selectedRequest.status === "pending" ? (
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-slate-450 tracking-wider mb-1">
                      Administrative Audit Remarks & Notes (Logged to Review History)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Registered character validated. Safe water certificates matched."
                      value={remarksInput}
                      onChange={(e) => setRemarksInput(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-slate-800"
                    />
                  </div>
                ) : (
                  <div className="p-3.5 bg-slate-50 border border-slate-150 rounded-lg text-xs">
                    <span className="block text-[9px] uppercase font-bold text-slate-400">Lock-in Audit Remarks</span>
                    <p className="font-semibold text-slate-700 leading-relaxed mt-1">
                      {selectedRequest.remarks || "No evaluation remarks recorded on file."}
                    </p>
                  </div>
                )}

                {/* Decline trigger form area */}
                {showDeclineReason && (
                  <div className="p-3 bg-red-50 border border-red-100 rounded-xl space-y-2 animate-in slide-in-from-bottom-2 duration-150">
                    <label className="block text-[10px] font-bold text-red-900">
                      Reason for Registry Decline (Communicated to applicant)
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        required
                        placeholder="e.g. Incomplete tax residency or missing CSR credentials."
                        value={declineReasonText}
                        onChange={(e) => setDeclineReasonText(e.target.value)}
                        className="flex-1 px-3 py-1 bg-white border border-red-200 rounded text-xs focus:ring-red-500"
                      />
                      <button
                        type="button"
                        onClick={() => executeDecline(selectedRequest.id)}
                        className="px-3 bg-red-650 hover:bg-red-700 font-bold text-white text-xs rounded"
                      >
                        Confirm Block
                      </button>
                    </div>
                  </div>
                )}

                {/* Final Decision Button Set */}
                <div className="flex justify-between items-center flex-wrap gap-3">
                  <div className="text-xs">
                    <span className="text-slate-450">Review Priority: </span>
                    <span className="font-bold text-amber-600">Standard Clearance</span>
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedRequest(null)}
                      className="px-4 py-1.5 bg-slate-50 border border-slate-200 hover:bg-slate-100 text-slate-500 hover:text-slate-800 font-bold text-xs rounded-lg transition-colors cursor-pointer"
                    >
                      Close Workspace
                    </button>

                    {selectedRequest.status === "pending" && (
                      <>
                        <button
                          type="button"
                          onClick={() => {
                            if (showDeclineReason) {
                              setShowDeclineReason(false);
                            } else {
                              setShowDeclineReason(true);
                            }
                          }}
                          className="px-4 py-1.5 bg-white text-[#C5192D] hover:bg-red-50 border border-red-200/55 font-bold text-xs rounded-lg transition-colors cursor-pointer"
                        >
                          Decline Request
                        </button>
                        
                        <button
                          type="button"
                          onClick={() => executeApproval(selectedRequest.id)}
                          className="px-5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg shadow-sm transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <ShieldCheck className="w-4 h-4" />
                          <span>Approve & Authorize Partner</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>

              </div>

            </div>
          </div>
        </div>
      )}

    </div>
  );
}
