import React, { useState } from "react";
import { Partner, SDG } from "../types";
import { 
  Plus, 
  Search, 
  Building2, 
  Mail, 
  Globe, 
  CheckCircle, 
  Trash2, 
  Check, 
  X, 
  Sparkles, 
  Eye, 
  EyeOff,
  Link2,
  FileCheck
} from "lucide-react";

interface PartnerManagementViewProps {
  partners: Partner[];
  sdgs: SDG[];
  onAddPartner: (partner: Partner) => void;
  onUpdatePartner: (updated: Partner) => void;
  onDeletePartner: (id: string) => void;
  searchTerm: string;
}

export default function PartnerManagementView({
  partners,
  sdgs,
  onAddPartner,
  onUpdatePartner,
  onDeletePartner,
  searchTerm: parentSearchTerm
}: PartnerManagementViewProps) {
  
  const [localSearch, setLocalSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<"all" | "school" | "ngo" | "company">("all");
  const [activeStatus, setActiveStatus] = useState<"all" | "verified" | "visible">("all");
  
  // Registration form drawer trigger and fields
  const [showAddPartner, setShowAddPartner] = useState(false);
  const [formName, setFormName] = useState("");
  const [formCategory, setFormCategory] = useState<"school" | "ngo" | "company">("ngo");
  const [formLogo, setFormLogo] = useState("");
  const [formWebsite, setFormWebsite] = useState("");
  const [formEmail, setFormEmail] = useState("");
  const [formBio, setFormBio] = useState("");
  const [formSelectedSDGs, setFormSelectedSDGs] = useState<number[]>([3, 4]);

  // Combined search term
  const effectiveSearch = (localSearch || parentSearchTerm).toLowerCase();

  // Filter partners
  const filteredPartners = partners.filter((p) => {
    // Search query
    const matchesSearch = p.name.toLowerCase().includes(effectiveSearch) || 
                          p.bio.toLowerCase().includes(effectiveSearch) ||
                          p.contactEmail.toLowerCase().includes(effectiveSearch);
    
    // Category pill
    const matchesCategory = activeCategory === "all" || p.category === activeCategory;

    // Status toggle
    const matchesStatus = 
      activeStatus === "all" ? true :
      activeStatus === "verified" ? p.verified :
      p.visibility; // visible

    return matchesSearch && matchesCategory && matchesStatus;
  });

  // Toggle SDGs checkboxes in register form
  const handleToggleSDGCheck = (id: number) => {
    if (formSelectedSDGs.includes(id)) {
      setFormSelectedSDGs(prev => prev.filter(item => item !== id));
    } else {
      setFormSelectedSDGs(prev => [...prev, id]);
    }
  };

  // Submit new partner
  const handleSubmitPartner = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    // Generate high-quality default mock logos depending on category if left blank
    const fallbacks = {
      school: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=120&auto=format&fit=crop&q=80",
      ngo: "https://images.unsplash.com/photo-1509099836639-18ba1795216d?w=120&auto=format&fit=crop&q=80",
      company: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=120&auto=format&fit=crop&q=80"
    };

    const newPartner: Partner = {
      id: "p-" + Date.now(),
      name: formName,
      category: formCategory,
      logoUrl: formLogo.trim() || fallbacks[formCategory],
      verified: true, // Admin registered are auto-verified
      website: formWebsite.trim() || "https://stepup.org",
      contactEmail: formEmail.trim() || "partnerships@stepup.org",
      visibility: true,
      registeredAt: new Date().toISOString().split("T")[0],
      activeSDGs: formSelectedSDGs,
      bio: formBio
    };

    onAddPartner(newPartner);
    setShowAddPartner(false);

    // Reset fields
    setFormName("");
    setFormLogo("");
    setFormWebsite("");
    setFormEmail("");
    setFormBio("");
    setFormSelectedSDGs([3, 4]);
  };

  // Toggle verification state helper
  const handleToggleVerify = (partner: Partner) => {
    const updated: Partner = {
      ...partner,
      verified: !partner.verified
    };
    onUpdatePartner(updated);
  };

  // Toggle visibility helper
  const handleToggleVisibility = (partner: Partner) => {
    const updated: Partner = {
      ...partner,
      visibility: !partner.visibility
    };
    onUpdatePartner(updated);
  };

  return (
    <div className="space-y-6">
      
      {/* Search and Filters Header */}
      <div className="bg-white p-5 border border-slate-200/80 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        {/* Inline Search and Category Pills */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 flex-1">
          <div className="relative max-w-xs">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              placeholder="Search by name, key terms..."
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              className="w-full pl-9 pr-6 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>

          {/* Category Filter Pills */}
          <div className="flex p-1 bg-slate-100 rounded-lg self-start sm:self-auto flex-wrap gap-0.5">
            {[
              { id: "all", label: "All Sectors" },
              { id: "school", label: "Schools Only" },
              { id: "ngo", label: "NGOs Only" },
              { id: "company", label: "Companies Only" }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveCategory(tab.id as any)}
                className={`px-3 py-1 text-xs font-bold rounded-md transition-colors cursor-pointer ${
                  activeCategory === tab.id 
                    ? "bg-white text-slate-900 shadow-xs" 
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Visibility / Status Filter and Add Button */}
        <div className="flex items-center gap-3 self-end md:self-auto">
          <select
            value={activeStatus}
            onChange={(e) => setActiveStatus(e.target.value as any)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold focus:outline-none text-slate-600"
          >
            <option value="all">All Registries</option>
            <option value="verified">Verified Hubs Only</option>
            <option value="visible">Activated on Public Website</option>
          </select>

          <button
            onClick={() => setShowAddPartner(!showAddPartner)}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-1.5 transition-colors focus:outline-none cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Register New Partner</span>
          </button>
        </div>

      </div>

      {/* Register New Partner Modal form */}
      {showAddPartner && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl w-full max-w-xl border border-slate-200 shadow-2xl overflow-hidden text-left. animate-in fade-in zoom-in duration-200">
            
            {/* Header ribbon */}
            <div className="h-1.5 w-full bg-blue-600" />
            
            <form onSubmit={handleSubmitPartner} className="p-6 space-y-4">
              <div className="flex justify-between items-center pb-3 border-b border-slate-100">
                <h3 className="font-bold font-display text-slate-900 text-sm flex items-center gap-2">
                  <FileCheck className="w-4.5 h-4.5 text-blue-600" />
                  Direct Register Verified Partner Organization
                </h3>
                <button 
                  type="button" 
                  onClick={() => setShowAddPartner(false)} 
                  className="p-1 hover:bg-slate-100 rounded text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1">
                    Organization Official Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Save the Forest Volunteers"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1">
                    Partner Category Sector
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as any)}
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none text-slate-800"
                  >
                    <option value="school">Educational School / Academy</option>
                    <option value="ngo">Registered NGO Activism Group</option>
                    <option value="company">Sponsoring Enterprise / Company</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1">
                    URL to Logo (Optional, preset default used)
                  </label>
                  <input
                    type="url"
                    placeholder="https://images.unsplash.com/photo-..."
                    value={formLogo}
                    onChange={(e) => setFormLogo(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1">
                    Official Website Link
                  </label>
                  <input
                    type="url"
                    required
                    placeholder="https://mygroup.org"
                    value={formWebsite}
                    onChange={(e) => setFormWebsite(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none text-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1">
                  Point of Contact Email (Confidential)
                </label>
                <input
                  type="email"
                  required
                  placeholder="poc@mygroup.org"
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none text-slate-800"
                />
              </div>

              {/* SDGs multi-select checks */}
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1.5">
                  Associated SDG Alignments (Multi-Select)
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 max-h-24 overflow-y-auto p-2 bg-slate-50 border border-slate-200 rounded-lg">
                  {sdgs.map((sdg) => {
                    const checked = formSelectedSDGs.includes(sdg.id);
                    return (
                      <button
                        type="button"
                        key={sdg.id}
                        onClick={() => handleToggleSDGCheck(sdg.id)}
                        className={`p-1 text-[10px] font-bold rounded-md border text-center transition-colors cursor-pointer ${
                          checked 
                            ? "text-white" 
                            : "bg-white text-slate-500 border-slate-200 hover:border-slate-350"
                        }`}
                        style={{ backgroundColor: checked ? sdg.color : undefined, borderColor: checked ? sdg.color : undefined }}
                      >
                        SDG {sdg.id}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1">
                  Organization Bio Narrative (Public)
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="What is this organization's role or local student action mandate..."
                  value={formBio}
                  onChange={(e) => setFormBio(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none text-slate-850"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddPartner(false)}
                  className="px-3 py-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 bg-slate-50 border border-slate-200 hover:bg-slate-100 rounded-lg"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm"
                >
                  Verify & Register Partner
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Grid List of Partner Cards */}
      {filteredPartners.length === 0 ? (
        <div className="p-16 border-2 border-dashed border-slate-200 rounded-2xl bg-white text-center">
          <p className="text-slate-400 font-bold text-sm">No partners match selected filters.</p>
          <p className="text-slate-400 text-xs mt-1">Try resetting search parameters to see all verified NGOs and schools.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredPartners.map((partner) => (
            <div 
              key={partner.id}
              className="bg-white border border-slate-200/80 rounded-2xl p-5 hover:shadow-md transition-all flex flex-col justify-between relative group"
            >
              <div>
                {/* Header within card */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex gap-3">
                    <img
                      src={partner.logoUrl}
                      alt={partner.name}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-200/80 shrink-0 shadow-xs"
                      referrerPolicy="no-referrer"
                    />

                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${
                          partner.category === "school" ? "bg-amber-100 text-amber-700" :
                          partner.category === "ngo" ? "bg-green-100 text-green-700" :
                          "bg-purple-100 text-purple-700"
                        }`}>
                          {partner.category}
                        </span>

                        {partner.verified ? (
                          <span className="inline-flex items-center gap-1 bg-emerald-50 text-[#4C9F38] px-1.5 py-0.5 rounded text-[8px] font-bold border border-emerald-100">
                            ✓ Verified Profile
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded text-[8px] font-bold border border-slate-200">
                            Awaiting Audit
                          </span>
                        )}
                      </div>

                      <h3 className="font-bold font-display text-slate-905 text-sm mt-1 group-hover:text-blue-750 transition-colors">
                        {partner.name}
                      </h3>
                    </div>
                  </div>

                  {/* Absolute delete in corner for admins */}
                  <button
                    onClick={() => onDeletePartner(partner.id)}
                    className="p-1 hover:bg-red-50 text-slate-300 hover:text-red-650 rounded transition-colors focus:outline-none shrink-0"
                    title="Terminate Partnership Agreement"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Profile short narrative */}
                <p className="text-xs text-slate-500 leading-relaxed font-medium mb-4 line-clamp-2" title={partner.bio}>
                  {partner.bio}
                </p>

                {/* Active aligned SDGs list */}
                <div className="space-y-1.5 mb-5">
                  <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider">
                    Aligned Action Goals
                  </span>
                  <div className="flex gap-1.5 flex-wrap">
                    {partner.activeSDGs.length === 0 ? (
                      <span className="text-[10px] text-slate-400 italic">None configured</span>
                    ) : (
                      partner.activeSDGs.map((id) => {
                        const matched = sdgs.find(s => s.id === id);
                        return (
                          <span
                            key={id}
                            className="px-2 py-0.5 rounded text-[9px] font-bold text-white shadow-xs"
                            style={{ backgroundColor: matched?.color || "#56C02B" }}
                            title={matched?.name}
                          >
                            {matched?.code || `SDG ${id}`}
                          </span>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>

              {/* Action buttons footer for verifying or visibility toggles */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between flex-wrap gap-2 text-xs">
                {/* Outlinks */}
                <div className="flex gap-2.5">
                  <a
                    href={partner.website}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 text-slate-400 hover:text-slate-700 font-bold"
                  >
                    <Globe className="w-3.5 h-3.5" />
                    <span>Website</span>
                  </a>
                  <a
                    href={`mailto:${partner.contactEmail}`}
                    className="inline-flex items-center gap-1 text-slate-400 hover:text-slate-700 font-bold"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>Email</span>
                  </a>
                </div>

                {/* Controls */}
                <div className="flex items-center gap-2">
                  {/* Verify Authenticity toggle */}
                  <button
                    onClick={() => handleToggleVerify(partner)}
                    className={`px-2.5 py-1 text-[10px] font-bold rounded-lg border flex items-center gap-1 transition-all focus:outline-none cursor-pointer ${
                      partner.verified
                        ? "bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200"
                        : "bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200"
                    }`}
                  >
                    <span>{partner.verified ? "De-authorize" : "Verify Authority"}</span>
                  </button>

                  {/* Public Visibility toggle */}
                  <button
                    onClick={() => handleToggleVisibility(partner)}
                    className={`px-2.5 py-1 text-[10px] font-bold rounded-lg border flex items-center gap-1 transition-all focus:outline-none cursor-pointer ${
                      partner.visibility
                        ? "bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
                        : "bg-amber-50 hover:bg-amber-100 text-amber-700 border-amber-200"
                    }`}
                  >
                    {partner.visibility ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                    <span>{partner.visibility ? "Visible" : "Hidden"}</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
}
