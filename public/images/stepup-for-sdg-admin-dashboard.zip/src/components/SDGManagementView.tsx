import React, { useState } from "react";
import { SDG, CaseStudy, SDGActivity } from "../types";
import { 
  BookOpen, 
  CalendarDays, 
  Sparkles, 
  Plus, 
  Trash2, 
  Edit3, 
  Save, 
  CheckCircle, 
  Clock, 
  Users, 
  Megaphone,
  X,
  Target
} from "lucide-react";

interface SDGManagementViewProps {
  sdgs: SDG[];
  onUpdateSDG: (updated: SDG) => void;
}

export default function SDGManagementView({ sdgs, onUpdateSDG }: SDGManagementViewProps) {
  const [selectedSdgId, setSelectedSdgId] = useState<number>(3); // Default to SDG 3
  const [isEditingBasic, setIsEditingBasic] = useState(false);

  // Form states for basic SDG update
  const [editName, setEditName] = useState("");
  const [editDesc, setEditDesc] = useState("");
  const [editColor, setEditColor] = useState("");
  const [editCampaigns, setEditCampaigns] = useState(0);

  // Add Case Study Form states
  const [showAddCaseStudy, setShowAddCaseStudy] = useState(false);
  const [csTitle, setCsTitle] = useState("");
  const [csLocation, setCsLocation] = useState("");
  const [csYear, setCsYear] = useState(2026);
  const [csOutcome, setCsOutcome] = useState("");
  const [csDesc, setCsDesc] = useState("");

  // Add SDG Activity Form states
  const [showAddActivity, setShowAddActivity] = useState(false);
  const [actTitle, setActTitle] = useState("");
  const [actDate, setActDate] = useState("");
  const [actLocation, setActLocation] = useState("");
  const [actCategory, setActCategory] = useState<"workshop" | "volunteer" | "awareness" | "fundraiser">("volunteer");
  const [actStudents, setActStudents] = useState(15);

  const selectedSdg = sdgs.find(s => s.id === selectedSdgId) || sdgs[0];

  // Initialize edit forms when selected SDG changes
  React.useEffect(() => {
    if (selectedSdg) {
      setEditName(selectedSdg.name);
      setEditDesc(selectedSdg.description);
      setEditColor(selectedSdg.color);
      setEditCampaigns(selectedSdg.awarenessCampaigns);
      setIsEditingBasic(false);
      setShowAddCaseStudy(false);
      setShowAddActivity(false);
    }
  }, [selectedSdgId, selectedSdg]);

  const handleSaveBasic = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSdg) return;
    const updated: SDG = {
      ...selectedSdg,
      name: editName,
      description: editDesc,
      color: editColor,
      awarenessCampaigns: Number(editCampaigns)
    };
    onUpdateSDG(updated);
    setIsEditingBasic(false);
  };

  const handleAddCaseStudySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSdg || !csTitle.trim()) return;

    const newCaseStudy: CaseStudy = {
      id: "cs-" + Date.now(),
      title: csTitle,
      location: csLocation,
      year: csYear,
      outcome: csOutcome,
      description: csDesc
    };

    const updated: SDG = {
      ...selectedSdg,
      caseStudies: [...selectedSdg.caseStudies, newCaseStudy]
    };

    onUpdateSDG(updated);
    setShowAddCaseStudy(false);
    // Reset fields
    setCsTitle("");
    setCsLocation("");
    setCsOutcome("");
    setCsDesc("");
  };

  const handleDeleteCaseStudy = (csId: string) => {
    if (!selectedSdg) return;
    const updated: SDG = {
      ...selectedSdg,
      caseStudies: selectedSdg.caseStudies.filter(c => c.id !== csId)
    };
    onUpdateSDG(updated);
  };

  const handleAddActivitySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSdg || !actTitle.trim()) return;

    const newActivity: SDGActivity = {
      id: "act-" + Date.now(),
      title: actTitle,
      date: actDate || "2026-06-12",
      location: actLocation || "Virtual Workshop Hub",
      category: actCategory,
      registeredStudents: Number(actStudents)
    };

    const updated: SDG = {
      ...selectedSdg,
      activities: [...selectedSdg.activities, newActivity]
    };

    onUpdateSDG(updated);
    setShowAddActivity(false);
    // Reset fields
    setActTitle("");
    setActDate("");
    setActLocation("");
    setActStudents(15);
  };

  const handleDeleteActivity = (actId: string) => {
    if (!selectedSdg) return;
    const updated: SDG = {
      ...selectedSdg,
      activities: selectedSdg.activities.filter(a => a.id !== actId)
    };
    onUpdateSDG(updated);
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
      
      {/* LEFT COLUMN: Modern Grid of SDG Selection Cards */}
      <div className="xl:col-span-4 space-y-4">
        <div className="bg-white p-4 border border-slate-200/80 rounded-2xl">
          <h3 className="font-bold font-display text-slate-900 text-sm mb-1">UN SDG Directory</h3>
          <p className="text-xs text-slate-400">Select any active Global Goal to configure and manage registered youth campaigns.</p>
          
          <div className="grid grid-cols-1 gap-2.5 mt-4">
            {sdgs.map((sdg) => {
              const isActive = sdg.id === selectedSdgId;
              return (
                <button
                  key={sdg.id}
                  onClick={() => setSelectedSdgId(sdg.id)}
                  className={`w-full p-3 rounded-xl border text-left transition-all flex items-start gap-3 group relative cursor-pointer ${
                    isActive 
                      ? "bg-slate-900 border-slate-900 shadow-sm"
                      : "bg-white hover:bg-slate-50 border-slate-200/80"
                  }`}
                >
                  {/* Colorful vertical edge */}
                  <div 
                    className="absolute left-0 top-0 bottom-0 w-1 rounded-l-xl" 
                    style={{ backgroundColor: sdg.color }}
                  />

                  {/* Icon Block */}
                  <div 
                    className="w-9 h-9 rounded-lg flex items-center justify-center font-bold text-white text-xs shrink-0 font-display shadow-xs"
                    style={{ backgroundColor: sdg.color }}
                  >
                    {sdg.id}
                  </div>

                  <div className="min-w-0">
                    <span className={`block text-[10px] font-bold font-mono uppercase tracking-wider ${
                      isActive ? "text-slate-400" : "text-slate-500"
                    }`}>
                      {sdg.code}
                    </span>
                    <h4 className={`font-bold font-display text-xs truncate ${
                      isActive ? "text-white" : "text-slate-800"
                    }`}>
                      {sdg.name}
                    </h4>
                    <span className={`text-[10px] block mt-0.5 font-medium ${isActive ? "text-slate-300" : "text-slate-500"}`}>
                      {sdg.activeProjects} active campaigns
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: Full Configurations of Selected SDG */}
      <div className="xl:col-span-8 space-y-6">
        
        {/* Basic Goal Information Card */}
        <div className="bg-white border border-slate-200/80 rounded-2xl overflow-hidden relative">
          {/* Accent Header Banner using SDG theme color */}
          <div className="h-2.5 w-full" style={{ backgroundColor: selectedSdg.color }} />
          
          <div className="p-5">
            <div className="flex justify-between items-center mb-4 flex-wrap gap-2">
              <div className="flex items-center gap-3">
                <span 
                  className="px-2.5 py-0.5 rounded font-mono font-bold text-white text-[11px]"
                  style={{ backgroundColor: selectedSdg.color }}
                >
                  {selectedSdg.code}
                </span>
                <h2 className="text-lg font-bold font-display text-slate-900">
                  {selectedSdg.name} Configuration Area
                </h2>
              </div>

              {!isEditingBasic ? (
                <button
                  onClick={() => setIsEditingBasic(true)}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 hover:bg-slate-100 text-slate-700 hover:text-slate-900 font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5 focus:outline-none cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Configure Metadata</span>
                </button>
              ) : (
                <div className="flex gap-2">
                  <button
                    onClick={() => setIsEditingBasic(false)}
                    className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-700 bg-slate-50 border border-slate-200 hover:bg-slate-100 font-bold rounded-lg transition-colors focus:outline-none"
                  >
                    Discard
                  </button>
                  <button
                    onClick={handleSaveBasic}
                    className="px-3 py-1.5 text-xs text-white bg-[#56C02B] hover:bg-[#47a61f] font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5 focus:outline-none"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Save Metadata</span>
                  </button>
                </div>
              )}
            </div>

            {/* View or Edit mode */}
            {!isEditingBasic ? (
              <div className="space-y-4">
                <p className="text-xs text-slate-650 leading-relaxed bg-slate-50/50 p-4 border border-slate-200/60 rounded-xl font-medium">
                  {selectedSdg.description}
                </p>

                {/* Micro Statistics Dashboard */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="p-3 bg-slate-55 rounded-xl border border-slate-150 text-center bg-slate-50/10">
                    <span className="block text-[10px] text-slate-400 uppercase font-bold tracking-wider">Metrics Managed</span>
                    <span className="text-base font-bold text-slate-800 mt-1 block">
                      {selectedSdg.impactCount.toLocaleString()} pts
                    </span>
                  </div>
                  <div className="p-3 bg-slate-55 rounded-xl border border-slate-150 text-center bg-slate-50/10">
                    <span className="block text-[10px] text-slate-400 uppercase font-bold tracking-wider">Student Force</span>
                    <span className="text-base font-bold text-slate-800 mt-1 block">
                      {selectedSdg.studentContributors} youths
                    </span>
                  </div>
                  <div className="p-3 bg-slate-55 rounded-xl border border-slate-150 text-center bg-slate-50/10">
                    <span className="block text-[10px] text-slate-400 uppercase font-bold tracking-wider">Awareness Campaigns</span>
                    <span className="text-base font-bold text-slate-800 mt-1 block">
                      {selectedSdg.awarenessCampaigns} active
                    </span>
                  </div>
                  <div className="p-3 bg-slate-55 rounded-xl border border-slate-150 text-center bg-slate-50/10">
                    <span className="block text-[10px] text-slate-400 uppercase font-bold tracking-wider">Thematic Theme Color</span>
                    <div className="flex items-center justify-center gap-1.5 mt-1">
                      <div className="w-3.5 h-3.5 rounded" style={{ backgroundColor: selectedSdg.color }} />
                      <span className="text-[11px] font-mono font-bold text-slate-600 uppercase">{selectedSdg.color}</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSaveBasic} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1">
                      SDG Objective Title
                    </label>
                    <input
                      type="text"
                      required
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1">
                        Accent Theme Color
                      </label>
                      <div className="flex gap-1.5 items-center">
                        <input
                          type="color"
                          value={editColor}
                          onChange={(e) => setEditColor(e.target.value)}
                          className="w-8 h-7 border border-slate-250 cursor-pointer rounded shrink-0 p-0"
                        />
                        <input
                          type="text"
                          required
                          value={editColor}
                          onChange={(e) => setEditColor(e.target.value)}
                          className="w-full px-2 py-1.5 border border-slate-200 rounded text-xs lowercase font-mono focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1">
                        Awareness Campaigns
                      </label>
                      <input
                        type="number"
                        min="0"
                        value={editCampaigns}
                        onChange={(e) => setEditCampaigns(Number(e.target.value))}
                        className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1">
                    Description & Youth Target Guidelines (Platform Public Bio)
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={editDesc}
                    onChange={(e) => setEditDesc(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20 leading-relaxed"
                  />
                </div>
              </form>
            )}
          </div>
        </div>

        {/* Dynamic Case Studies Section */}
        <div className="bg-white border border-slate-200/80 rounded-2xl p-5">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="font-bold font-display text-slate-900 text-sm flex items-center gap-2">
                <BookOpen className="w-4.5 h-4.5 text-blue-600" />
                Featured Real-Life Case Studies
              </h3>
              <p className="text-xs text-slate-400">Public success stories showing measurable NGO performance.</p>
            </div>

            <button
              onClick={() => setShowAddCaseStudy(!showAddCaseStudy)}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-1 transition-colors focus:outline-none cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Sponsor Case Study</span>
            </button>
          </div>

          {/* Add Case Study Form Drawer */}
          {showAddCaseStudy && (
            <form onSubmit={handleAddCaseStudySubmit} className="p-4 rounded-xl border border-blue-100 bg-blue-50/15 space-y-3 mb-4">
              <div className="flex justify-between items-center pb-2 border-b border-blue-50">
                <h4 className="text-xs font-bold text-blue-900">Add New Success Case Study</h4>
                <button type="button" onClick={() => setShowAddCaseStudy(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-550 mb-0.5">Title</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Clean Canopy Reforestation"
                    value={csTitle}
                    onChange={(e) => setCsTitle(e.target.value)}
                    className="w-full px-2 py-1 bg-white border border-slate-200 rounded text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-550 mb-0.5">Location / Town</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Chicago West Side"
                    value={csLocation}
                    onChange={(e) => setCsLocation(e.target.value)}
                    className="w-full px-2 py-1 bg-white border border-slate-200 rounded text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-550 mb-0.5">Primary Outcome Accomplished</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Planted 2,500 trees reducing heat by 12%"
                    value={csOutcome}
                    onChange={(e) => setCsOutcome(e.target.value)}
                    className="w-full px-2 py-1 bg-white border border-slate-200 rounded text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-550 mb-0.5">Publishing Year</label>
                  <input
                    type="number"
                    min="2020"
                    max="2030"
                    required
                    value={csYear}
                    onChange={(e) => setCsYear(Number(e.target.value))}
                    className="w-full px-2 py-1 bg-white border border-slate-200 rounded text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-550 mb-0.5">Extended Narrative / Background</label>
                <textarea
                  rows={2}
                  required
                  placeholder="Summarize the core logistics, tools sourced, and group engagement..."
                  value={csDesc}
                  onChange={(e) => setCsDesc(e.target.value)}
                  className="w-full px-2 py-1 bg-white border border-slate-200 rounded text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowAddCaseStudy(false)}
                  className="px-2.5 py-1 text-[11px] font-semibold text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="px-3 py-1 text-[11px] font-bold text-white bg-blue-600 hover:bg-blue-500 rounded shadow-xs"
                >
                  Approve Publication
                </button>
              </div>
            </form>
          )}

          {/* List Of Case Studies */}
          <div className="space-y-3">
            {selectedSdg.caseStudies.length === 0 ? (
              <div className="p-8 border border-dashed border-slate-250 text-center text-xs text-slate-400 bg-slate-50/50 rounded-xl font-medium">
                No real-life case studies cataloged for this goal yet. Click "Sponsor Case Study" to add the first.
              </div>
            ) : (
              selectedSdg.caseStudies.map((cs) => (
                <div 
                  key={cs.id} 
                  className="p-4 border border-slate-150 rounded-xl bg-slate-50/20 hover:bg-slate-50/70 transition-colors relative group"
                >
                  <button
                    onClick={() => handleDeleteCaseStudy(cs.id)}
                    className="absolute top-3.5 right-3.5 p-1 hover:bg-red-50 text-slate-350 hover:text-red-600 rounded transition-colors focus:outline-none"
                    title="Delete Case Study"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>

                  <div className="pr-8">
                    <span className="text-[9px] font-bold font-mono text-blue-600 uppercase tracking-wider bg-blue-50 border border-blue-100/50 px-2 py-0.5 rounded">
                      Case #{cs.id.slice(-4)} • {cs.location} • {cs.year}
                    </span>
                    <h4 className="font-bold text-slate-905 text-xs mt-2">{cs.title}</h4>
                    <p className="text-[11px] text-slate-500 leading-relaxed mt-1">{cs.description}</p>
                    <div className="mt-2.5 pt-2 border-t border-slate-100/60 text-[11px] text-[#4C9F38] font-semibold flex items-center gap-1.5">
                      <Target className="w-3.5 h-3.5" />
                      <span>Outcome Secured: {cs.outcome}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Dynamic SDG Student Activities Center */}
        <div className="bg-white border border-slate-200/80 rounded-2xl p-5">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="font-bold font-display text-slate-900 text-sm flex items-center gap-2">
                <CalendarDays className="w-4.5 h-4.5 text-[#DDA63A]" />
                Youth Contribution Activities & Campaigns
              </h3>
              <p className="text-xs text-slate-400">Interactive ecological assignments open to schools and individuals.</p>
            </div>

            <button
              onClick={() => setShowAddActivity(!showAddActivity)}
              className="px-3 py-1.5 bg-[#DDA63A] hover:bg-[#c9952e] text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-1 transition-colors focus:outline-none cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Schedule Event</span>
            </button>
          </div>

          {/* Add Activity Form Drawer */}
          {showAddActivity && (
            <form onSubmit={handleAddActivitySubmit} className="p-4 rounded-xl border border-amber-100 bg-amber-50/15 space-y-3 mb-4">
              <div className="flex justify-between items-center pb-2 border-b border-amber-100">
                <h4 className="text-xs font-bold text-amber-900">Configure New Youth Activity Event</h4>
                <button type="button" onClick={() => setShowAddActivity(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-550 mb-0.5">Campaign/Event Title</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Seashore Plastic Micro-audit"
                    value={actTitle}
                    onChange={(e) => setActTitle(e.target.value)}
                    className="w-full px-2 py-1 bg-white border border-slate-200 rounded text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-550 mb-0.5">Target Location</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. North Coast Wildlife Reserve"
                    value={actLocation}
                    onChange={(e) => setActLocation(e.target.value)}
                    className="w-full px-2 py-1 bg-white border border-slate-200 rounded text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-550 mb-0.5">Event Execution Date</label>
                  <input
                    type="date"
                    required
                    value={actDate}
                    onChange={(e) => setActDate(e.target.value)}
                    className="w-full px-2 py-1 bg-white border border-slate-200 rounded text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-550 mb-0.5">Activity Categorization</label>
                  <select
                    value={actCategory}
                    onChange={(e) => setActCategory(e.target.value as any)}
                    className="w-full px-2 py-1 bg-white border border-slate-200 rounded text-xs"
                  >
                    <option value="volunteer">Volunteer Fieldwork</option>
                    <option value="workshop">Educational Workshop</option>
                    <option value="awareness">Awareness Campaign</option>
                    <option value="fundraiser">CSR Fundraiser</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-550 mb-0.5">Starting Volunteers Logted</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={actStudents}
                    onChange={(e) => setActStudents(Number(e.target.value))}
                    className="w-full px-2 py-1 bg-white border border-slate-200 rounded text-xs"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowAddActivity(false)}
                  className="px-2.5 py-1 text-[11px] font-semibold text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="px-3 py-1 text-[11px] font-bold text-white bg-[#DDA63A] hover:bg-[#c9952e] rounded shadow-xs"
                >
                  Confirm Event Schedule
                </button>
              </div>
            </form>
          )}

          {/* Table display of Events */}
          <div className="overflow-x-auto">
            {selectedSdg.activities.length === 0 ? (
              <div className="p-8 border border-dashed border-slate-250 text-center text-xs text-slate-400 bg-slate-50/50 rounded-xl font-medium">
                No student contribution activities scheduled. Click "Schedule Event" to list one.
              </div>
            ) : (
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                    <th className="py-2.5 px-2">Campaign Title</th>
                    <th className="py-2.5 px-2">Scheduling Date</th>
                    <th className="py-2.5 px-2">Location Venue</th>
                    <th className="py-2.5 px-2">Category</th>
                    <th className="py-2.5 px-2">Subscribers</th>
                    <th className="py-2.5 px-2 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {selectedSdg.activities.map((act) => (
                    <tr key={act.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="py-3 px-2 font-bold text-slate-800">{act.title}</td>
                      <td className="py-3 px-2 text-slate-500 font-medium whitespace-nowrap">{act.date}</td>
                      <td className="py-3 px-2 text-slate-500">{act.location}</td>
                      <td className="py-3 px-2 uppercase text-[9px] font-bold whitespace-nowrap">
                        <span className={`px-2 py-0.5 rounded-full ${
                          act.category === "volunteer" ? "bg-emerald-50 text-emerald-600 border border-emerald-100" :
                          act.category === "workshop" ? "bg-blue-50 text-blue-600 border border-blue-100" :
                          act.category === "awareness" ? "bg-purple-50 text-purple-600 border border-purple-100" :
                          "bg-amber-50 text-amber-600 border border-amber-100"
                        }`}>
                          {act.category}
                        </span>
                      </td>
                      <td className="py-3 px-2 font-semibold text-slate-700">
                        <span className="inline-flex items-center gap-1 bg-slate-100 border border-slate-200 px-1.5 py-0.5 rounded text-[10px]">
                          <Users className="w-3 h-3 text-slate-400" />
                          {act.registeredStudents}
                        </span>
                      </td>
                      <td className="py-3 px-2 text-right">
                        <button
                          onClick={() => handleDeleteActivity(act.id)}
                          className="p-1 hover:bg-red-50 text-slate-350 hover:text-red-650 rounded transition-colors"
                          title="Prune Activity"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
