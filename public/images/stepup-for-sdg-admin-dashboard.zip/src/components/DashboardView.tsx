import React, { useState } from "react";
import { SDG, Partner, ReviewRequest, InquiryMessage } from "../types";
import { 
  Building2, 
  Map, 
  Layers, 
  ShieldAlert, 
  TrendingUp, 
  Users, 
  ArrowUpRight, 
  ChevronRight, 
  Heart,
  Lightbulb,
  Clock,
  Sparkles,
  ExternalLink
} from "lucide-react";

interface DashboardViewProps {
  partners: Partner[];
  sdgs: SDG[];
  reviewRequests: ReviewRequest[];
  inquiries: InquiryMessage[];
  setActiveTab: (tab: string) => void;
  onApproveRequest: (id: string) => void;
  onDeclineRequest: (id: string, reason: string) => void;
}

export default function DashboardView({
  partners,
  sdgs,
  reviewRequests,
  inquiries,
  setActiveTab,
  onApproveRequest,
  onDeclineRequest
}: DashboardViewProps) {
  const [hoveredBarIndex, setHoveredBarIndex] = useState<number | null>(null);

  // Derive dynamic metrics
  const totalPartners = partners.length;
  const verifiedPartners = partners.filter(p => p.verified).length;
  const totalActiveProjects = sdgs.reduce((sum, s) => sum + s.activeProjects, 0);
  const pendingRequests = reviewRequests.filter(r => r.status === "pending");
  const pendingRequestsCount = pendingRequests.length;
  const totalStudentContributions = sdgs.reduce((sum, s) => sum + s.studentContributors, 0);
  const totalImpactCount = sdgs.reduce((sum, s) => sum + s.impactCount, 0);

  // Active projects list for project progress cards
  const progressProjects = [
    { name: "Urban Reforestation & Heat Audits", sdg: "SDG 13", progress: 84, color: "#3F7E44", leader: "Oakridge Science High", volunteers: 400 },
    { name: "Rural Digital Literacy Labs", sdg: "SDG 4", progress: 68, color: "#C5192D", leader: "Youth Empowerment Initiative", volunteers: 130 },
    { name: "Clean Reservoir Bio-plastic filters", sdg: "SDG 6", progress: 41, color: "#26BDE2", leader: "Green Horizon alliance", volunteers: 64 },
    { name: "Solar Rechargeable Reading Luminaires", sdg: "SDG 7", progress: 92, color: "#FCC30B", leader: "Solaris Global Renewables", volunteers: 200 }
  ];

  // Activities feed
  const recentActivities = [
    { id: "act-1", text: "Apex Eco-Logistics logged request to deploy 12 sustainability student dashboards.", type: "review", time: "10 minutes ago" },
    { id: "act-2", text: "Oakridge Science high logged 32 new volunteers for 'Free Book Fair & Library Setup'.", type: "achievement", time: "2 hours ago" },
    { id: "act-3", text: "Dr. Sarah Hamilton submitted a Joint Hackathon event proposal for SDG 13.", type: "inquiry", time: "4 hours ago" },
    { id: "act-4", text: "New case study added: 'Pollinator Pathways & Bee Habitats' under SDG 15 (Life on Land).", type: "system", time: "1 day ago" }
  ];

  // Custom data for custom gorgeous SVG charts
  // Months: January to June 2026. Cumulative Impact Count.
  const chartData = [
    { month: "Jan", impact: 12000, students: 800 },
    { month: "Feb", impact: 19500, students: 1100 },
    { month: "Mar", impact: 28000, students: 1650 },
    { month: "Apr", impact: 35400, students: 2300 },
    { month: "May", impact: 43200, students: 2800 },
    { month: "Jun", impact: totalImpactCount, students: totalStudentContributions }
  ];

  const barChartSDGs = sdgs.slice(0, 6); // Grab first 6 SDGs to draw inside nice horizontal bar
  const maxImpactValue = Math.max(...barChartSDGs.map(s => s.impactCount), 1000);

  return (
    <div className="space-y-6 pt-2">
      
      {/* Inspirational Header Grid */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl text-white relative overflow-hidden shadow-md">
        <div className="absolute inset-0 z-0 opacity-20 pointer-events-none bg-[radial-gradient(ellipse_at_top_right,rgba(37,99,235,0.4)_0%,transparent_70%)]" />
        <div className="relative z-10 max-w-4xl">
          <span className="text-blue-400 font-bold tracking-widest text-[10px] uppercase font-mono px-2.5 py-1 rounded bg-blue-500/10 border border-blue-500/15">
            Liaison Oversight Console
          </span>
          <h1 className="text-2xl md:text-3xl font-bold font-display mt-3 leading-tight text-white">
            Green Portal Impact Operations
          </h1>
          <p className="text-slate-300 text-xs md:text-sm max-w-2xl mt-1.5 leading-relaxed">
            Welcome back, Super Admin. There are currently <span className="font-semibold text-[#26BDE2]">{pendingRequestsCount} active partnership requests</span> awaiting review. Platform youth engagement has increased by <span className="text-[#56C02B] font-semibold">+14% this week</span>.
          </p>
        </div>
      </div>

      {/* Statistics Cards Bento-Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
        
        {/* Partners */}
        <div 
          onClick={() => setActiveTab("partner")}
          className="lg:col-span-1 p-4 bg-white border border-slate-200/80 rounded-xl hover:shadow-md cursor-pointer transition-all active:translate-y-[1px] group relative overflow-hidden"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Partners</span>
            <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Building2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold font-display text-slate-900">{totalPartners}</p>
          <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
            <span className="text-emerald-600 font-semibold">{verifiedPartners} verified</span>
          </div>
          <div className="absolute right-1 bottom-1 p-0.5 text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity">
            <ArrowUpRight className="w-3 h-3" />
          </div>
        </div>

        {/* Total SDGs */}
        <div 
          onClick={() => setActiveTab("sdg")}
          className="lg:col-span-1 p-4 bg-white border border-slate-200/80 rounded-xl hover:shadow-md cursor-pointer transition-all active:translate-y-[1px] group relative overflow-hidden"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Active SDGs</span>
            <div className="w-7 h-7 rounded-lg bg-amber-50 text-[#DDA63A] flex items-center justify-center">
              <Map className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold font-display text-slate-900">{sdgs.length}</p>
          <div className="text-[10px] text-slate-400 mt-1">
            <span>of 17 global goals</span>
          </div>
          <div className="absolute right-1 bottom-1 p-0.5 text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity">
            <ArrowUpRight className="w-3 h-3" />
          </div>
        </div>

        {/* Active Projects */}
        <div className="lg:col-span-1 p-4 bg-white border border-slate-200/80 rounded-xl hover:shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Projects</span>
            <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold font-display text-slate-900">{totalActiveProjects}</p>
          <div className="text-[10px] text-slate-400 mt-1">
            <span className="text-emerald-600 font-semibold">9 ongoing campaigns</span>
          </div>
        </div>

        {/* Pending Partnerships */}
        <div 
          onClick={() => setActiveTab("review")}
          className={`lg:col-span-1 p-4 rounded-xl cursor-pointer transition-all active:translate-y-[1px] group relative overflow-hidden border ${
            pendingRequestsCount > 0 
              ? "bg-red-50/50 border-red-200 hover:shadow-md shadow-red-50" 
              : "bg-white border-slate-200/80 hover:shadow-xs"
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Pending Revs</span>
            <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${
              pendingRequestsCount > 0 ? "bg-red-100 text-red-600" : "bg-slate-100 text-slate-600"
            }`}>
              <ShieldAlert className="w-4 h-4" />
            </div>
          </div>
          <p className={`text-2xl font-bold font-display ${pendingRequestsCount > 0 ? "text-red-650" : "text-slate-950"}`}>
            {pendingRequestsCount}
          </p>
          <div className="text-[10px] mt-1">
            {pendingRequestsCount > 0 ? (
              <span className="text-red-500 font-bold">Needs action soon</span>
            ) : (
              <span className="text-slate-400">All caught up</span>
            )}
          </div>
          {pendingRequestsCount > 0 && (
            <div className="absolute right-1 bottom-1 p-0.5 text-red-500">
              <ArrowUpRight className="w-3 h-3" />
            </div>
          )}
        </div>

        {/* Student Contributors */}
        <div className="lg:col-span-1 p-4 bg-white border border-slate-200/80 rounded-xl hover:shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Youth Force</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 text-[#56C02B] flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold font-display text-slate-900">
            {totalStudentContributions.toLocaleString()}
          </p>
          <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-[#56C02B]" />
            <span className="text-emerald-600 font-semibold">+18% MoM</span>
          </div>
        </div>

        {/* Total Impact Count */}
        <div className="lg:col-span-1 p-4 bg-[#EAF2FF] border border-[#CBDFFF] rounded-xl hover:shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-blue-800 uppercase tracking-wider">Total Impact</span>
            <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
              <Heart className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold font-display text-blue-950">
            {totalImpactCount.toLocaleString()}
          </p>
          <div className="text-[10px] text-blue-700 font-medium mt-1">
            <span>Points Registered</span>
          </div>
        </div>

      </div>

      {/* Main Analytics: Gorgeous Interactive Svg Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Chart 1: Progressive Cumulative Youth Impact (Area Chart look) */}
        <div className="lg:col-span-7 bg-white p-5 border border-slate-200/80 rounded-2xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-bold font-display text-slate-900 tracking-tight flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-blue-600" />
                Live Dynamic Impact Progress (H1 2026)
              </h3>
              <span className="text-[10px] text-slate-400 uppercase font-mono font-bold">Points Registry</span>
            </div>
            <p className="text-xs text-slate-500">
              Visualizes the verified aggregate social, energy restoration, and education impact logs generated across counties.
            </p>
          </div>

          {/* SVG Rendering area chart */}
          <div className="relative h-56 w-full mt-4 flex items-end">
            
            {/* Horizontal Grid lines */}
            <div className="absolute inset-0 flex flex-col justify-between pointer-events-none mt-2 pb-6">
              <div className="h-px w-full bg-slate-100 border-dashed" />
              <div className="h-px w-full bg-slate-100 border-dashed" />
              <div className="h-px w-full bg-slate-100 border-dashed" />
              <div className="h-px w-full bg-slate-100 border-dashed" />
            </div>

            <svg className="w-full h-42 overflow-visible" viewBox="0 0 600 160">
              {/* Area gradient definition */}
              <defs>
                <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2563EB" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#2563EB" stopOpacity="0.00" />
                </linearGradient>
              </defs>

              {/* Grid vertical dots */}
              <circle cx="50" cy="130" r="1.5" fill="#94A3B8" />
              <circle cx="150" cy="115" r="1.5" fill="#94A3B8" />
              <circle cx="250" cy="95" r="1.5" fill="#94A3B8" />
              <circle cx="350" cy="78" r="1.5" fill="#94A3B8" />
              <circle cx="450" cy="55" r="1.5" fill="#94A3B8" />
              <circle cx="550" cy="15" r="1.5" fill="#94A3B8" />

              {/* Area path */}
              <path
                d="M 50 160 L 50 130 L 150 115 L 250 95 L 350 78 L 450 55 L 550 15 L 550 160 Z"
                fill="url(#areaGrad)"
              />

              {/* Line path */}
              <path
                d="M 50 130 L 150 115 L 250 95 L 350 78 L 450 55 L 550 15"
                fill="none"
                stroke="#2563EB"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />

              {/* Data points */}
              <g>
                <circle cx="50" cy="130" r="4.5" fill="white" stroke="#2563EB" strokeWidth="2" name="Jan" />
                <circle cx="150" cy="115" r="4.5" fill="white" stroke="#2563EB" strokeWidth="2" name="Feb" />
                <circle cx="250" cy="95" r="4.5" fill="white" stroke="#2563EB" strokeWidth="2" name="Mar" />
                <circle cx="350" cy="78" r="4.5" fill="white" stroke="#2563EB" strokeWidth="2" name="Apr" />
                <circle cx="450" cy="55" r="4.5" fill="white" stroke="#2563EB" strokeWidth="2" name="May" />
                <circle cx="550" cy="15" r="5" fill="#2563EB" stroke="white" strokeWidth="2" className="animate-pulse" />
              </g>

              {/* Tooltip label at peak */}
              <g transform="translate(500, 10)">
                <rect x="-85" y="-22" width="130" height="18" rx="4" fill="#0F172A" />
                <text x="-20" y="-10" fill="white" fontSize="9" fontWeight="bold" textAnchor="middle">
                  Current: {totalImpactCount.toLocaleString()} pts
                </text>
              </g>
            </svg>

            {/* X Axis Labels */}
            <div className="absolute inset-x-0 bottom-0 flex justify-between px-3 text-[10px] text-slate-400 font-bold">
              {chartData.map((d, i) => (
                <div key={i} className="text-center w-8">
                  <span>{d.month}</span>
                </div>
              ))}
            </div>

          </div>

          <div className="grid grid-cols-2 gap-4 border-t border-slate-100 pt-4 mt-2">
            <div className="text-center">
              <span className="block text-[10px] text-slate-400 uppercase font-bold">Average Registration rate</span>
              <span className="text-sm font-bold text-slate-800">485 active/mo</span>
            </div>
            <div className="text-center">
              <span className="block text-[10px] text-slate-400 uppercase font-bold">Engagement Index</span>
              <span className="text-sm font-bold text-[#56C02B]">High (8.2/10)</span>
            </div>
          </div>
        </div>

        {/* Chart 2: SDG Distribution comparative metrics */}
        <div className="lg:col-span-5 bg-white p-5 border border-slate-200/80 rounded-2xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-bold font-display text-slate-900 tracking-tight flex items-center gap-1.5">
                <Lightbulb className="w-4 h-4 text-[#DDA63A]" />
                Impact Points Per Selected SDG
              </h3>
              <span className="text-xs text-slate-400 font-mono">Rankings</span>
            </div>
            <p className="text-xs text-slate-500">
              SDG 13 (Climate Action) remains the highest registered student volunteer theme this quarter.
            </p>
          </div>

          {/* Elegant customized horizontal list representation of SDG impacts */}
          <div className="space-y-3 mt-4">
            {barChartSDGs.map((sdg_item) => {
              const percentage = Math.min(Math.round((sdg_item.impactCount / maxImpactValue) * 100), 100);
              return (
                <div key={sdg_item.id} className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-2.5 h-2.5 rounded" 
                        style={{ backgroundColor: sdg_item.color }} 
                      />
                      <span className="font-bold text-slate-800 text-[11px] font-display">{sdg_item.code}: {sdg_item.name}</span>
                    </div>
                    <span className="text-slate-500 font-semibold font-mono text-[10px]">{sdg_item.impactCount.toLocaleString()} pts</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                    <div 
                      className="h-full rounded-full transition-all duration-500"
                      style={{ 
                        width: `${percentage}%`,
                        backgroundColor: sdg_item.color
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-3 border-t border-slate-100 mt-4 text-center">
            <button 
              onClick={() => setActiveTab("sdg")}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 inline-flex items-center gap-1 hover:underline"
            >
              <span>Explore all SDG statistics pages</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>

      </div>

      {/* Grid: Project Progress & Recent Activities */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* 1. Projects Progress Board */}
        <div className="lg:col-span-8 bg-white p-5 border border-slate-200/80 rounded-2xl">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="text-sm font-bold font-display text-slate-900 tracking-tight">Active Platform Youth Initiatives</h3>
              <p className="text-xs text-slate-500">Milestone percentage registered of approved community proposals.</p>
            </div>
            <span className="px-2.5 py-1 text-[10px] bg-slate-100 text-slate-600 font-bold rounded-lg border border-slate-200">
              4 Active
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {progressProjects.map((project, i) => (
              <div 
                key={i} 
                className="p-3.5 rounded-xl border border-slate-150/80 hover:border-slate-300 bg-slate-50/20 hover:bg-slate-50/50 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-start">
                    <span className="text-[10px] font-bold font-display uppercase px-2 py-0.5 rounded text-white" style={{ backgroundColor: project.color }}>
                      {project.sdg}
                    </span>
                    <span className="text-[10px] text-slate-400 font-semibold">{project.volunteers} Students</span>
                  </div>
                  <h4 className="font-semibold text-slate-800 text-xs mt-2 line-clamp-1">
                    {project.name}
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 font-medium truncate">Lead: {project.leader}</p>
                </div>

                <div className="mt-4">
                  <div className="flex justify-between text-[10px] text-slate-500 font-bold mb-1">
                    <span>Audit Phase</span>
                    <span>{project.progress}% completed</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                    <div 
                      className="h-full rounded-full transition-all duration-500"
                      style={{ 
                        width: `${project.progress}%`,
                        backgroundColor: project.color
                      }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 2. Timeline Recent Activities */}
        <div className="lg:col-span-4 bg-white p-5 border border-slate-200/80 rounded-2xl flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold font-display text-slate-900 tracking-tight mb-1">Live Activity Registry</h3>
            <p className="text-xs text-slate-500">System actions executed across security logs.</p>
          </div>

          <div className="space-y-4 mt-4">
            {recentActivities.map((act) => (
              <div key={act.id} className="relative pl-5 pb-1 flex gap-2 text-xs">
                {/* Visual timeline bullet */}
                <div className="absolute left-0.5 top-1.5 w-1.5 h-1.5 rounded-full bg-blue-500 ring-4 ring-blue-50 z-10" />
                <div className="absolute left-1 top-2.5 w-0.5 h-full bg-slate-100 -z-0" />
                
                <div className="flex-1 min-w-0">
                  <p className="text-slate-650 leading-relaxed text-[11px]">
                    {act.text}
                  </p>
                  <span className="text-[9px] text-slate-400 font-bold flex items-center gap-1.5 mt-1">
                    <Clock className="w-3 h-3 text-slate-400" />
                    {act.time}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-100 mt-4 text-center">
            <span className="text-[10px] uppercase font-bold text-slate-400">
              Status Flag: Audit System Secured
            </span>
          </div>
        </div>

      </div>

      {/* Bottom Row: Pending Partnerships Quick Summary Review */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-5">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="text-sm font-bold font-display text-slate-900 tracking-tight flex items-center gap-2">
              <ShieldAlert className="w-4.5 h-4.5 text-red-500" />
              Partnership Request Pending Queue
            </h3>
            <p className="text-xs text-slate-500">Critical approval pipeline of registered entities requiring state authorization.</p>
          </div>
          <button 
            onClick={() => setActiveTab("review")}
            className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
          >
            <span>Open Review Center</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {pendingRequests.length === 0 ? (
          <div className="p-8 border border-dashed border-slate-200 rounded-xl bg-slate-50/50 text-center text-xs text-slate-400 font-semibold">
            Zero pending reviews! All incoming school and corporate applications are current.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-450 uppercase font-bold tracking-wider">
                  <th className="py-2 px-3">Organization</th>
                  <th className="py-2 px-3">Category</th>
                  <th className="py-2 px-3">Registry Inquiry Date</th>
                  <th className="py-2 px-3">Target SDGs</th>
                  <th className="py-2 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {pendingRequests.map((req) => (
                  <tr key={req.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-3 px-3 font-semibold text-slate-800 flex items-center gap-2">
                      <img 
                        src={req.logoUrl} 
                        alt={req.partnerName} 
                        className="w-6 h-6 rounded-md object-cover border border-slate-200 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <span>{req.partnerName}</span>
                    </td>
                    <td className="py-3 px-3 uppercase text-[10px] font-bold">
                      <span className={`px-2 py-0.5 rounded-full ${
                        req.category === "school" ? "bg-amber-50 text-amber-600 border border-amber-200/50" :
                        req.category === "ngo" ? "bg-green-50 text-green-600 border border-green-200/50" :
                        "bg-purple-50 text-purple-600 border border-purple-200/50"
                      }`}>
                        {req.category}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-500 font-medium">{req.requestedAt}</td>
                    <td className="py-3 px-3">
                      <div className="flex gap-1.5 flex-wrap">
                        {req.appliedSDGs.map((id) => {
                          const matching = sdgs.find(s => s.id === id);
                          return (
                            <span 
                              key={id} 
                              className="px-1.5 py-0.5 text-[9px] font-bold rounded text-white"
                              style={{ backgroundColor: matching?.color || "#64748B" }}
                              title={matching?.name}
                            >
                              SDG {id}
                            </span>
                          );
                        })}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => setActiveTab("review")}
                        className="px-2.5 py-1 text-xs font-bold text-blue-600 hover:text-white hover:bg-blue-600 border border-blue-600/30 rounded-md transition-colors"
                      >
                        Inspect Application
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
}
