import React, { useState } from "react";
import { 
  Bell, 
  Search, 
  Settings, 
  Menu, 
  ChevronDown, 
  CheckCircle, 
  User, 
  ShieldAlert,
  Sliders,
  CalendarDays
} from "lucide-react";

interface Notification {
  id: string;
  title: string;
  description: string;
  time: string;
  read: boolean;
  type: "review" | "inquiry" | "alert";
}

interface TopNavProps {
  title: string;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  adminEmail: string;
  onNavigateSettings: () => void;
  onLogout: () => void;
  searchTerm: string;
  setSearchTerm: (val: string) => void;
}

export default function TopNav({
  title,
  sidebarOpen,
  setSidebarOpen,
  adminEmail,
  onNavigateSettings,
  onLogout,
  searchTerm,
  setSearchTerm
}: TopNavProps) {
  
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfile, setShowProfile] = useState(false);

  // Cool real notifications
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: "n-1",
      title: "New Review Application",
      description: "Apex Eco-Logistics submitted 3 validation charters.",
      time: "10 mins ago",
      read: false,
      type: "review"
    },
    {
      id: "n-2",
      title: "Incoming Collaboration",
      description: "Sarah Hamilton requested a Joint SDG Hackathon.",
      time: "2 hours ago",
      read: false,
      type: "inquiry"
    },
    {
      id: "n-3",
      title: "Security Clearance OK",
      description: "Weekly directory health check validated clean.",
      time: "1 day ago",
      read: true,
      type: "alert"
    }
  ]);

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const clearNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 md:px-6 bg-white border-b border-slate-200/80 shadow-xs backdrop-blur-md bg-white/95">
      
      {/* Left side: Hamburger menu + Title */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg lg:hidden focus:outline-none"
          title="Open Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <h2 className="text-lg md:text-xl font-bold font-display text-slate-900 tracking-tight flex items-center gap-2">
            {title}
          </h2>
        </div>
      </div>

      {/* Middle side: Search bar */}
      <div className="hidden md:flex items-center flex-1 max-w-sm mx-8">
        <div className="relative w-full">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            placeholder="Search partners, SDGs, or review lists..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-8 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-850 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-colors bg-slate-100/50"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm("")}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 text-[10px] uppercase font-bold"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Right side: Actions & User profile */}
      <div className="flex items-center gap-3.5">
        
        {/* Quick Help reminder or time */}
        <div className="hidden lg:flex items-center gap-1.5 text-xs text-slate-500 font-medium bg-slate-50 px-2.5 py-1.5 border border-slate-200/60 rounded-lg">
          <CalendarDays className="w-3.5 h-3.5 text-blue-600" />
          <span>June 2026 Admin Portal</span>
        </div>

        {/* Notifications Icon Tray */}
        <div className="relative">
          <button
            onClick={() => {
              setShowNotifications(!showNotifications);
              setShowProfile(false);
            }}
            className="relative p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-full focus:outline-none transition-colors"
            title="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-red-600 text-white rounded-full text-[9px] font-bold flex items-center justify-center animate-pulse">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Notifications Dropdown */}
          {showNotifications && (
            <>
              <div 
                className="fixed inset-0 z-40 bg-transparent" 
                onClick={() => setShowNotifications(false)} 
              />
              <div className="absolute right-0 mt-2 z-50 w-80 bg-white border border-slate-200 rounded-xl shadow-xl py-3 text-left">
                <div className="flex items-center justify-between px-4 pb-2 border-b border-slate-100">
                  <span className="font-semibold text-slate-800 text-xs">Alert Registry</span>
                  {unreadCount > 0 && (
                    <button 
                      onClick={markAllRead} 
                      className="text-[10px] text-blue-600 hover:text-blue-700 font-bold hover:underline"
                    >
                      Clear Badge
                    </button>
                  )}
                </div>

                <div className="max-h-64 overflow-y-auto divide-y divide-slate-50">
                  {notifications.length === 0 ? (
                    <div className="px-4 py-8 text-center text-xs text-slate-400">
                      Zero unread notifications. All tasks set.
                    </div>
                  ) : (
                    notifications.map((n) => (
                      <div 
                        key={n.id} 
                        className={`p-3.5 hover:bg-slate-50 transition-colors flex items-start gap-2.5 ${n.read ? "opacity-75" : "bg-blue-50/20"}`}
                      >
                        <div className="mt-0.5 shrink-0">
                          {n.type === "review" && <CheckCircle className="w-4 h-4 text-emerald-500" />}
                          {n.type === "inquiry" && <CalendarDays className="w-4 h-4 text-blue-500" />}
                          {n.type === "alert" && <ShieldAlert className="w-4 h-4 text-amber-500" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-slate-800 text-xs truncate">{n.title}</p>
                          <p className="text-[11px] text-slate-500 line-clamp-2 mt-0.5">{n.description}</p>
                          <p className="text-[9px] text-slate-400 mt-1 font-semibold">{n.time}</p>
                        </div>
                        <button
                          onClick={() => clearNotification(n.id)}
                          className="text-slate-350 hover:text-slate-600 text-xs p-0.5"
                          title="Dismiss"
                        >
                          ×
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Global Settings Shortcut */}
        <button
          onClick={onNavigateSettings}
          className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-full transition-colors hidden sm:block focus:outline-none"
          title="Account Settings"
        >
          <Settings className="w-5 h-5" />
        </button>

        {/* Vertical divider */}
        <span className="h-6 w-px bg-slate-200 block" />

        {/* User profile actions */}
        <div className="relative">
          <button
            onClick={() => {
              setShowProfile(!showProfile);
              setShowNotifications(false);
            }}
            className="flex items-center gap-2 text-left focus:outline-none cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-full bg-slate-900 border border-slate-200 overflow-hidden flex items-center justify-center font-bold text-white text-xs font-display">
              AD
            </div>
            <div className="hidden lg:block leading-tight">
              <span className="block text-xs font-semibold text-slate-800 group-hover:text-blue-600 transition-colors">Super Admin</span>
              <span className="text-[10px] text-slate-400 capitalize">{adminEmail.split("@")[0]}</span>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-600 shrink-0" />
          </button>

          {/* Profile Dropdown */}
          {showProfile && (
            <>
              <div 
                className="fixed inset-0 z-40 bg-transparent" 
                onClick={() => setShowProfile(false)} 
              />
              <div className="absolute right-0 mt-2 z-50 w-56 bg-white border border-slate-200 rounded-xl shadow-xl py-2 divide-y divide-slate-100 text-left">
                <div className="px-4 py-2 bg-slate-50/50">
                  <p className="text-xs font-bold text-slate-800">UN Environmental Bureau</p>
                  <p className="text-[11px] text-slate-500 truncate mt-0.5">{adminEmail}</p>
                </div>

                <div className="py-1">
                  <button
                    onClick={() => {
                      onNavigateSettings();
                      setShowProfile(false);
                    }}
                    className="w-full px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2.5"
                  >
                    <User className="w-4 h-4 text-slate-400" />
                    <span>My Profile</span>
                  </button>
                  <button
                    onClick={() => {
                      onNavigateSettings();
                      setShowProfile(false);
                    }}
                    className="w-full px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2.5"
                  >
                    <Sliders className="w-4 h-4 text-slate-400" />
                    <span>Portal Settings</span>
                  </button>
                </div>

                <div className="py-1">
                  <button
                    onClick={() => {
                      setShowProfile(false);
                      onLogout();
                    }}
                    className="w-full px-4 py-2 text-xs text-red-600 hover:bg-red-50/50 flex items-center gap-2.5 font-semibold"
                  >
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

      </div>
    </header>
  );
}
