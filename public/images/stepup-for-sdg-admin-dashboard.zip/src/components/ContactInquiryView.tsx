import React, { useState } from "react";
import { InquiryMessage } from "../types";
import { 
  Mail, 
  Send, 
  CheckCircle, 
  Clock, 
  Search, 
  MessageSquare, 
  Sparkles, 
  Trash2, 
  User, 
  Inbox, 
  AlertCircle,
  FileHeart,
  CornerDownLeft,
  X
} from "lucide-react";

interface ContactInquiryViewProps {
  inquiries: InquiryMessage[];
  onReplyInquiry: (id: string, responseMessage: string) => void;
  onDeleteInquiry: (id: string) => void;
}

export default function ContactInquiryView({
  inquiries,
  onReplyInquiry,
  onDeleteInquiry
}: ContactInquiryViewProps) {
  
  const [selectedId, setSelectedId] = useState<string>(inquiries[0]?.id || "");
  const [inboxSearch, setInboxSearch] = useState("");
  const [inboxCategory, setInboxCategory] = useState<"all" | "partnership" | "sdg" | "feedback" | "general">("all");
  const [inboxStatus, setInboxStatus] = useState<"all" | "unread" | "read" | "replied">("all");
  
  // Custom draft replies
  const [replyDraft, setReplyDraft] = useState("");
  const [showDraftFeedback, setShowDraftFeedback] = useState(false);

  const activeInquiry = inquiries.find(i => i.id === selectedId) || inquiries[0];

  // Filters process
  const filteredInquiries = inquiries.filter((inq) => {
    // Search match
    const searchLow = inboxSearch.toLowerCase();
    const queryMatches = inq.senderName.toLowerCase().includes(searchLow) ||
                         inq.subject.toLowerCase().includes(searchLow) ||
                         inq.message.toLowerCase().includes(searchLow);
    
    // Category match
    const categoryMatches = inboxCategory === "all" || inq.category === inboxCategory;

    // Status match
    const statusMatches = 
      inboxStatus === "all" ? true :
      inboxStatus === "unread" ? inq.status === "unread" :
      inboxStatus === "read" ? inq.status === "read" :
      inq.status === "replied";

    return queryMatches && categoryMatches && statusMatches;
  });

  const handleSelectInquiry = (inq: InquiryMessage) => {
    setSelectedId(inq.id);
    setReplyDraft("");
    setShowDraftFeedback(false);
    
    // If selecting an unread message, let's mark it as 'read' immediately
    if (inq.status === "unread") {
      // Inline status adjustment to read
      inq.status = "read";
    }
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyDraft.trim() || !activeInquiry) return;

    onReplyInquiry(activeInquiry.id, replyDraft.trim());
    setReplyDraft("");
    setShowDraftFeedback(true);

    // Fade help notification out after some time
    setTimeout(() => {
      setShowDraftFeedback(false);
    }, 3000);
  };

  return (
    <div className="bg-white border border-slate-200/80 rounded-2xl overflow-hidden shadow-xs h-[calc(100vh-12rem)] min-h-[500px] flex flex-col">
      
      {/* Top Header Controls bar */}
      <div className="bg-slate-50 p-4 border-b border-slate-200/80 flex flex-col md:flex-row md:items-center justify-between gap-3 flex-wrap">
        
        {/* Category Pill select */}
        <div className="flex gap-1.5 flex-wrap">
          {[
            { id: "all", label: "All Inboxes" },
            { id: "partnership", label: "Partnerships" },
            { id: "sdg", label: "SDG Metrics" },
            { id: "feedback", label: "System Feedback" },
            { id: "general", label: "General" }
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setInboxCategory(cat.id as any)}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                inboxCategory === cat.id
                  ? "bg-slate-900 text-white shadow-xs"
                  : "bg-white text-slate-550 border border-slate-200 hover:border-slate-350 hover:text-slate-800"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Quick status selective list */}
        <div className="flex items-center gap-3">
          <select
            value={inboxStatus}
            onChange={(e) => setInboxStatus(e.target.value as any)}
            className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-bold font-sans text-slate-600 focus:outline-none"
          >
            <option value="all">Deliverability Status: All</option>
            <option value="unread">Unread Submissions</option>
            <option value="read">Opened / Ignored</option>
            <option value="replied">Dispatched Replies</option>
          </select>
        </div>

      </div>

      {/* Main Inbox Double-Pane Frame */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* LEFT PANE: Directory of inbox messages */}
        <div className="w-full md:w-80 lg:w-96 border-r border-slate-200/80 flex flex-col bg-white overflow-hidden">
          
          {/* Quick Search inside Inbox */}
          <div className="p-3.5 border-b border-slate-100 bg-slate-50/20">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400">
                <Search className="w-3.5 h-3.5" />
              </div>
              <input
                type="text"
                placeholder="Search subject or emails..."
                value={inboxSearch}
                onChange={(e) => setInboxSearch(e.target.value)}
                className="w-full pl-8 pr-6 py-1.5 bg-white border border-slate-200 rounded-lg text-xs focus:outline-none"
              />
            </div>
          </div>

          {/* Submissions items row */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-50">
            {filteredInquiries.length === 0 ? (
              <div className="py-20 text-center text-slate-400 text-xs flex flex-col items-center justify-center gap-2">
                <Inbox className="w-8 h-8 text-slate-300" />
                <span>Zero inquiries match this directory.</span>
              </div>
            ) : (
              filteredInquiries.map((inq) => {
                const isSelected = inq.id === selectedId;
                const dateClean = new Date(inq.date).toLocaleDateString([], { month: 'short', day: 'numeric' });
                
                return (
                  <button
                    key={inq.id}
                    onClick={() => handleSelectInquiry(inq)}
                    className={`w-full p-4 text-left transition-colors flex items-start gap-3 cursor-pointer ${
                      isSelected 
                        ? "bg-blue-50/35 border-l-4 border-blue-600" 
                        : "hover:bg-slate-50 border-l-4 border-transparent"
                    }`}
                  >
                    {/* Status Dot */}
                    <div className="mt-1 shrink-0">
                      {inq.status === "unread" && (
                        <span className="w-2.5 h-2.5 rounded-full bg-blue-600 block animate-pulse" title="Unread" />
                      )}
                      {inq.status === "read" && (
                        <span className="w-2.5 h-2.5 rounded-full bg-slate-200 block" title="Opened" />
                      )}
                      {inq.status === "replied" && (
                        <span className="w-2.5 h-2.5 rounded-full bg-[#56C02B] block" title="Replied" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-bold text-slate-900 text-xs truncate">{inq.senderName}</span>
                        <span className="text-[10px] text-slate-400 font-bold whitespace-nowrap">{dateClean}</span>
                      </div>
                      
                      <p className={`text-xs mt-0.5 truncate ${inq.status === "unread" ? "font-bold text-slate-950" : "text-slate-550"}`}>
                        {inq.subject}
                      </p>

                      <p className="text-[11px] text-slate-400 line-clamp-1 mt-1 font-medium">
                        {inq.message}
                      </p>

                      {/* category code */}
                      <span className="inline-block mt-2 px-1.5 py-0.5 rounded text-[8px] font-bold uppercase border bg-slate-50 text-slate-500 border-slate-150">
                        {inq.category}
                      </span>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* RIGHT PANE: Focused item conversation inspector */}
        <div className="flex-1 bg-slate-50/30 flex flex-col justify-between overflow-hidden">
          {activeInquiry ? (
            <div className="flex-1 flex flex-col justify-between overflow-hidden">
              
              {/* Message Header and quick action */}
              <div className="bg-white p-4 border-b border-slate-200/80 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-slate-900 text-sm leading-tight flex items-center gap-2">
                    {activeInquiry.subject}
                  </h3>
                  <div className="flex items-center gap-2 mt-1.5 text-xs text-slate-500 flex-wrap">
                    <span className="font-semibold text-slate-805 flex items-center gap-1">
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      {activeInquiry.senderName}
                    </span>
                    <span>&lt;{activeInquiry.senderEmail}&gt;</span>
                    <span>•</span>
                    <span className="font-semibold">{new Date(activeInquiry.date).toLocaleString()}</span>
                  </div>
                </div>

                <button
                  onClick={() => onDeleteInquiry(activeInquiry.id)}
                  className="p-1.5 hover:bg-red-50 text-slate-350 hover:text-red-650 rounded-lg transition-colors focus:outline-none"
                  title="Archive Communication Submission"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Message history log scroll region */}
              <div className="flex-1 p-5 overflow-y-auto space-y-4">
                
                {/* Original Query Bubble */}
                <div className="flex gap-3 max-w-2xl bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 font-display font-medium text-xs">
                    {activeInquiry.senderName.slice(0, 2).toUpperCase()}
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-xs">{activeInquiry.senderName}</span>
                      <span className="text-[10px] text-slate-450 uppercase font-mono px-1.5 py-0.5 rounded bg-slate-50">
                        Visitor query
                      </span>
                    </div>
                    <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-line font-medium pt-1">
                      {activeInquiry.message}
                    </p>
                  </div>
                </div>

                {/* History responses thread */}
                {activeInquiry.history.map((log, l_idx) => {
                  const isAdmin = log.sender === "admin";
                  return (
                    <div 
                      key={l_idx} 
                      className={`flex gap-3 max-w-2xl p-4 rounded-xl border ${
                        isAdmin 
                          ? "ml-auto bg-[#EAF2FF] border-[#CBDFFF]/80" 
                          : "bg-white border-slate-200"
                      }`}
                    >
                      {isAdmin ? (
                        <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center shrink-0 font-bold font-display text-[10px] order-2">
                          UN
                        </div>
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 font-bold font-display text-[10px]">
                          {activeInquiry.senderName.slice(0, 2).toUpperCase()}
                        </div>
                      )}

                      <div className={`space-y-1 ${isAdmin ? "order-1 mr-2 text-right flex-1" : "flex-1"}`}>
                        <div className="flex items-center gap-2 justify-start sm:justify-between flex-wrap">
                          <span className="font-bold text-slate-900 text-xs">
                            {isAdmin ? "Super Admin (Dispatched Response)" : activeInquiry.senderName}
                          </span>
                          <span className="text-[9px] text-slate-400 font-bold">
                            {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-line text-left pt-1 font-semibold">
                          {log.message}
                        </p>
                      </div>
                    </div>
                  );
                })}

                {/* Local alert feedback banner */}
                {showDraftFeedback && (
                  <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-100 text-[#4C9F38] text-[11px] font-bold flex items-center gap-2.5 animate-pulse">
                    <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
                    <span>Dispatched draft reply secure. Status has updated to "replied" on general review server.</span>
                  </div>
                )}
              </div>

              {/* Compose response footer board */}
              <div className="bg-white p-4 border-t border-slate-200/80">
                <form onSubmit={handleSendReply} className="space-y-3">
                  <div className="relative">
                    <div className="absolute top-2.5 left-3 text-slate-400 flex items-center gap-1.5">
                      <CornerDownLeft className="w-3.5 h-3.5" />
                      <span className="text-[9px] uppercase font-bold tracking-wider text-slate-450">Administrative Response</span>
                    </div>
                    <textarea
                      rows={3}
                      required
                      placeholder="Type your official response text here. Backed-citizens receive verified notification..."
                      value={replyDraft}
                      onChange={(e) => setReplyDraft(e.target.value)}
                      className="w-full pt-8 pb-3 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-slate-850 placeholder-slate-400 leading-relaxed"
                    />
                  </div>

                  <div className="flex justify-between items-center flex-wrap gap-2">
                    <span className="text-[10px] text-slate-400 font-bold">
                      Responding as: <strong className="text-slate-605">lasyareddipatlolla71415@gmail.com</strong>
                    </span>

                    <button
                      type="submit"
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors focus:outline-none cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Dispatch Encrypted Communication</span>
                    </button>
                  </div>
                </form>
              </div>

            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-400 text-xs">
              <Inbox className="w-12 h-12 text-slate-300 mb-2" />
              <span>Please select an inquiry from the inbox column list.</span>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
