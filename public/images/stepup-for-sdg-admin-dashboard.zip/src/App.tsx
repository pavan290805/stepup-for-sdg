import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import Login from "./components/Login";
import Sidebar from "./components/Sidebar";
import TopNav from "./components/TopNav";
import DashboardView from "./components/DashboardView";
import SDGManagementView from "./components/SDGManagementView";
import PartnerManagementView from "./components/PartnerManagementView";
import ReviewCenterView from "./components/ReviewCenterView";
import ContactInquiryView from "./components/ContactInquiryView";
import SettingsView from "./components/SettingsView";
import { SDG, Partner, ReviewRequest, InquiryMessage } from "./types";
import { 
  initialSDGs, 
  initialPartners, 
  initialReviewRequests, 
  initialInquiries 
} from "./data/mockData";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [adminEmail, setAdminEmail] = useState("admin@stepup.org");
  const [activeTab, setActiveTab] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [globalSearch, setGlobalSearch] = useState("");

  // Core synchronized state engines
  const [sdgs, setSdgs] = useState<SDG[]>(initialSDGs);
  const [partners, setPartners] = useState<Partner[]>(initialPartners);
  const [reviewRequests, setReviewRequests] = useState<ReviewRequest[]>(initialReviewRequests);
  const [inquiries, setInquiries] = useState<InquiryMessage[]>(initialInquiries);

  // Read stored session on load
  useEffect(() => {
    const stored = localStorage.getItem("stepup_admin_session");
    if (stored) {
      setAdminEmail(stored);
      setIsAuthenticated(true);
    }
  }, []);

  const handleLoginSuccess = (email: string) => {
    setAdminEmail(email);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem("stepup_admin_session");
    setIsAuthenticated(false);
    setActiveTab("dashboard");
  };

  // State Updates: SDG config metadata
  const handleUpdateSDG = (updatedSDG: SDG) => {
    setSdgs(prev => prev.map(item => item.id === updatedSDG.id ? updatedSDG : item));
  };

  // State Updates: Partners Directory
  const handleAddPartner = (newPartner: Partner) => {
    setPartners(prev => [newPartner, ...prev]);
  };

  const handleUpdatePartner = (updatedPartner: Partner) => {
    setPartners(prev => prev.map(item => item.id === updatedPartner.id ? updatedPartner : item));
  };

  const handleDeletePartner = (id: string) => {
    if (window.confirm("Are you sure you want to terminate this partnership registry on StepUp?")) {
      setPartners(prev => prev.filter(item => item.id !== id));
    }
  };

  // State Updates: Review Center - Approve
  const handleApproveRequest = (id: string, remarksInput?: string) => {
    const targetReq = reviewRequests.find(r => r.id === id);
    if (!targetReq) return;

    // 1. Update request status in state
    setReviewRequests(prev => prev.map(r => r.id === id ? {
      ...r,
      status: "approved",
      remarks: remarksInput || "Authorized after standard documentation check."
    } : r));

    // 2. Automatically register this application as a real live partner!
    const newPartner: Partner = {
      id: "p-" + Date.now(),
      name: targetReq.partnerName,
      category: targetReq.category,
      logoUrl: targetReq.logoUrl,
      verified: true,
      website: targetReq.website,
      contactEmail: targetReq.email,
      visibility: true,
      registeredAt: new Date().toISOString().split("T")[0],
      activeSDGs: targetReq.appliedSDGs,
      bio: targetReq.details
    };

    setPartners(prev => [newPartner, ...prev]);
  };

  // State Updates: Review Center - Decline
  const handleDeclineRequest = (id: string, reason: string) => {
    setReviewRequests(prev => prev.map(r => r.id === id ? {
      ...r,
      status: "declined",
      remarks: `Declined on audit. Reason: ${reason}`
    } : r));
  };

  // State Updates: Inbox inquiries responses
  const handleReplyInquiry = (id: string, responseMessage: string) => {
    setInquiries(prev => prev.map(inq => {
      if (inq.id === id) {
        return {
          ...inq,
          status: "replied",
          history: [
            ...inq.history,
            {
              sender: "admin",
              message: responseMessage,
              timestamp: new Date().toISOString()
            }
          ]
        };
      }
      return inq;
    }));
  };

  const handleDeleteInquiry = (id: string) => {
    setInquiries(prev => prev.filter(item => item.id !== id));
  };

  // Derived indicator states
  const pendingRequestsCount = reviewRequests.filter(r => r.status === "pending").length;
  const unreadInquiriesCount = inquiries.filter(i => i.status === "unread").length;

  return (
    <div className="min-h-screen bg-slate-50/50 text-slate-800 antialiased font-sans flex flex-col selection:bg-blue-600 selection:text-white">
      
      {!isAuthenticated ? (
        <Login onLoginSuccess={handleLoginSuccess} />
      ) : (
        <div className="flex flex-1 overflow-hidden min-h-screen">
          
          {/* Static Sidebar Navigation on desktop, Drawer transition on responsive */}
          <Sidebar 
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            isOpen={sidebarOpen}
            setIsOpen={setSidebarOpen}
            onLogout={handleLogout}
            pendingCount={pendingRequestsCount}
            unreadInquiries={unreadInquiriesCount}
          />

          {/* Main workspace frame right side */}
          <div className="flex-1 flex flex-col lg:pl-68 overflow-hidden min-h-screen">
            
            {/* Sticky Top Bar Panel */}
            <TopNav 
              title={
                activeTab === "dashboard" ? "Admin Oversight Desktop" :
                activeTab === "sdg" ? "SDG Target Management" :
                activeTab === "partner" ? "Affiliated Partner Directory" :
                activeTab === "review" ? "Partnership Verification Centre" :
                activeTab === "inquiry" ? "Stakeholder Inquiry Terminal" :
                "Authorized Workspace Parameters"
              }
              sidebarOpen={sidebarOpen}
              setSidebarOpen={setSidebarOpen}
              adminEmail={adminEmail}
              onNavigateSettings={() => setActiveTab("settings")}
              onLogout={handleLogout}
              searchTerm={globalSearch}
              setSearchTerm={setGlobalSearch}
            />

            {/* Render Tab Views with fine staggered motion animations */}
            <main className="flex-1 p-4 md:p-6 overflow-y-auto max-w-7xl w-full mx-auto pb-12">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.25, ease: "easeOut" }}
                >
                  {activeTab === "dashboard" && (
                    <DashboardView 
                      partners={partners}
                      sdgs={sdgs}
                      reviewRequests={reviewRequests}
                      inquiries={inquiries}
                      setActiveTab={setActiveTab}
                      onApproveRequest={handleApproveRequest}
                      onDeclineRequest={handleDeclineRequest}
                    />
                  )}

                  {activeTab === "sdg" && (
                    <SDGManagementView 
                      sdgs={sdgs}
                      onUpdateSDG={handleUpdateSDG}
                    />
                  )}

                  {activeTab === "partner" && (
                    <PartnerManagementView 
                      partners={partners}
                      sdgs={sdgs}
                      onAddPartner={handleAddPartner}
                      onUpdatePartner={handleUpdatePartner}
                      onDeletePartner={handleDeletePartner}
                      searchTerm={globalSearch}
                    />
                  )}

                  {activeTab === "review" && (
                    <ReviewCenterView 
                      requests={reviewRequests}
                      sdgs={sdgs}
                      onApprove={handleApproveRequest}
                      onDecline={handleDeclineRequest}
                    />
                  )}

                  {activeTab === "inquiry" && (
                    <ContactInquiryView 
                      inquiries={inquiries}
                      onReplyInquiry={handleReplyInquiry}
                      onDeleteInquiry={handleDeleteInquiry}
                    />
                  )}

                  {activeTab === "settings" && (
                    <SettingsView 
                      adminEmail={adminEmail}
                      setAdminEmail={setAdminEmail}
                    />
                  )}
                </motion.div>
              </AnimatePresence>
            </main>

            {/* Minimalist Professional Footer */}
            <footer className="mt-auto px-6 py-4 bg-white border-t border-slate-200/50 text-[11px] text-slate-400 flex flex-col sm:flex-row justify-between items-center gap-2">
              <span>© 2026 StepUp for SDG Platform. United Nations Development Guidelines Compliant.</span>
              <div className="flex gap-4">
                <span className="hover:text-slate-600 transition-colors cursor-help">Technical Manual v4.1</span>
                <span>•</span>
                <span className="hover:text-slate-600 transition-colors cursor-help">Charity Security Assurance Protocol</span>
              </div>
            </footer>

          </div>
        </div>
      )}
    </div>
  );
}
