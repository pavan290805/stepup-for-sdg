export interface SDG {
  id: number;
  code: string; // e.g. "SDG 1"
  name: string;
  description: string;
  color: string;
  activeProjects: number;
  impactCount: number;
  studentContributors: number;
  awarenessCampaigns: number;
  caseStudies: CaseStudy[];
  activities: SDGActivity[];
}

export interface CaseStudy {
  id: string;
  title: string;
  location: string;
  year: number;
  outcome: string;
  description: string;
}

export interface SDGActivity {
  id: string;
  title: string;
  date: string;
  location: string;
  category: "workshop" | "volunteer" | "awareness" | "fundraiser";
  registeredStudents: number;
}

export interface Partner {
  id: string;
  name: string;
  category: "school" | "ngo" | "company";
  logoUrl: string;
  verified: boolean;
  website: string;
  contactEmail: string;
  visibility: boolean;
  registeredAt: string;
  activeSDGs: number[]; // SDG ids
  bio: string;
}

export interface ReviewRequest {
  id: string;
  partnerName: string;
  category: "school" | "ngo" | "company";
  logoUrl: string;
  status: "pending" | "approved" | "declined";
  requestedAt: string;
  email: string;
  website: string;
  details: string;
  remarks?: string;
  documents: { label: string; url: string; verified: boolean }[];
  appliedSDGs: number[];
}

export interface InquiryMessage {
  id: string;
  senderName: string;
  senderEmail: string;
  subject: string;
  message: string;
  date: string;
  category: "partnership" | "sdg" | "general" | "feedback";
  status: "unread" | "read" | "replied";
  history: {
    sender: "admin" | "visitor";
    message: string;
    timestamp: string;
  }[];
}

export interface DashboardStats {
  totalPartners: number;
  totalSDGs: number;
  activeProjects: number;
  pendingRequests: number;
  studentContributions: number;
  totalImpactCount: number;
}
