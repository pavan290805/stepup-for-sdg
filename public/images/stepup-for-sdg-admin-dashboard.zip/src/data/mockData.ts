import { SDG, Partner, ReviewRequest, InquiryMessage } from "../types";

export const initialSDGs: SDG[] = [
  {
    id: 1,
    code: "SDG 1",
    name: "No Poverty",
    description: "End poverty in all its forms everywhere by supporting social safety nets and local resource equity.",
    color: "#E5243B",
    activeProjects: 4,
    impactCount: 1420,
    studentContributors: 154,
    awarenessCampaigns: 2,
    caseStudies: [
      {
        id: "cs-1-1",
        title: "Community Micro-Loans for Single Mothers",
        location: "Nairobi Suburbs",
        year: 2025,
        outcome: "Helped 45 families launch self-sustaining craft shops, lifting the average household income by 120%.",
        description: "A pilot micro-financing program in collaboration with local credit unions, backed by student volunteers."
      }
    ],
    activities: [
      {
        id: "act-1-1",
        title: "Winter Care Package Packaging",
        date: "2026-04-12",
        location: "Downtown Community Hall",
        category: "volunteer",
        registeredStudents: 42
      }
    ]
  },
  {
    id: 3,
    code: "SDG 3",
    name: "Good Health and Well-being",
    description: "Ensure healthy lives and promote well-being for all at all ages through preventative vaccination and medical accessibility.",
    color: "#4C9F38",
    activeProjects: 6,
    impactCount: 3820,
    studentContributors: 310,
    awarenessCampaigns: 4,
    caseStudies: [
      {
        id: "cs-3-1",
        title: "Campus Mental Resilience Initiative",
        location: "Metro University",
        year: 2025,
        outcome: "Created 24/7 student chat hotline and reduced emergency counseling wait times from 14 days to zero.",
        description: "Peers-supporting-peers mental health directory and professional support routing."
      }
    ],
    activities: [
      {
        id: "act-3-1",
        title: "SDG 3 Health & Wellness Seminar",
        date: "2026-06-20",
        location: "Health Sciences Theater",
        category: "workshop",
        registeredStudents: 85
      },
      {
        id: "act-3-2",
        title: "Blood Donation Drive",
        date: "2026-07-01",
        location: "Main Gymnasium",
        category: "volunteer",
        registeredStudents: 150
      }
    ]
  },
  {
    id: 4,
    code: "SDG 4",
    name: "Quality Education",
    description: "Ensure inclusive and equitable quality education and promote lifelong learning opportunities for all.",
    color: "#C5192D",
    activeProjects: 12,
    impactCount: 9500,
    studentContributors: 620,
    awarenessCampaigns: 5,
    caseStudies: [
      {
        id: "cs-4-1",
        title: "Digital Literacy & Coding for Rural Girls",
        location: "Phnom Penh Outskirts",
        year: 2024,
        outcome: "Trained 130 girls in essential web design and python basics; 12 received full university tech scholarships.",
        description: "Provided refurbished laptops, remote high-quality learning hubs, and local mentors."
      },
      {
        id: "cs-4-2",
        title: "After-school STEM Mentorship Labs",
        location: "Chicago West Side",
        year: 2025,
        outcome: "Increased state exam performance in algebra by 34% among participating schools.",
        description: "Partnering schools matched high school juniors with college computer engineering students."
      }
    ],
    activities: [
      {
        id: "act-4-1",
        title: "Coding Bootcamp Teaching Assistantship",
        date: "2026-06-15",
        location: "Community Center Lab",
        category: "volunteer",
        registeredStudents: 18
      },
      {
        id: "act-4-2",
        title: "Free Book Fair & Library Setup",
        date: "2026-08-05",
        location: "South Elementary School",
        category: "volunteer",
        registeredStudents: 32
      }
    ]
  },
  {
    id: 5,
    code: "SDG 5",
    name: "Gender Equality",
    description: "Achieve gender equality and empower all women and girls through leadership mentorship and combatting tech wage gaps.",
    color: "#FF3A21",
    activeProjects: 3,
    impactCount: 2200,
    studentContributors: 184,
    awarenessCampaigns: 3,
    caseStudies: [
      {
        id: "cs-5-1",
        title: "Women in STEM Leadership Accelerator",
        location: "Tech District Hub",
        year: 2025,
        outcome: "Mentored 75 high school graduates; 90% entered STEM fields at university level.",
        description: "Monthly executive panels and summer research shadow programs."
      }
    ],
    activities: [
      {
        id: "act-5-1",
        title: "Women in Tech Mentoring Kickoff",
        date: "2026-06-25",
        location: "Innovation Incubator Lounge",
        category: "workshop",
        registeredStudents: 55
      }
    ]
  },
  {
    id: 6,
    code: "SDG 6",
    name: "Clean Water & Sanitation",
    description: "Ensure availability and sustainable management of water and sanitation for all through community filter installations.",
    color: "#26BDE2",
    activeProjects: 5,
    impactCount: 4500,
    studentContributors: 110,
    awarenessCampaigns: 3,
    caseStudies: [
      {
        id: "cs-6-1",
        title: "Rainwater Harvesting Systems in Arid Districts",
        location: "Rajasthan Villages",
        year: 2025,
        outcome: "Constructed 4 scalable storage wells supplying 10,000 liters of safe drinking water per monsoon.",
        description: "Leveraged eco-friendly geo-textiles and simple gravity-based filters designed with student engineering clubs."
      }
    ],
    activities: [
      {
        id: "act-6-1",
        title: "Lake Clean-up Drive",
        date: "2026-06-18",
        location: "Bluepoint Reservoir Park",
        category: "volunteer",
        registeredStudents: 64
      }
    ]
  },
  {
    id: 7,
    code: "SDG 7",
    name: "Affordable & Clean Energy",
    description: "Ensure access to affordable, reliable, sustainable and modern energy for all by scaling community solar panels.",
    color: "#FCC30B",
    activeProjects: 7,
    impactCount: 6200,
    studentContributors: 240,
    awarenessCampaigns: 3,
    caseStudies: [
      {
        id: "cs-7-1",
        title: "Solar Lantern Library for Offgrid Students",
        location: "Mindanao Islands",
        year: 2024,
        outcome: "Distributed 200 solar recharge panels to schoolhouses, enabling evening homework without kerosene risks.",
        description: "Students can borrow rechargeable LED study lamps daily from the school master."
      }
    ],
    activities: [
      {
        id: "act-7-1",
        title: "DIY Solar Panel Assembly Workshop",
        date: "2026-06-30",
        location: "Eco-Engineering Maker Lab",
        category: "workshop",
        registeredStudents: 40
      }
    ]
  },
  {
    id: 13,
    code: "SDG 13",
    name: "Climate Action",
    description: "Take urgent action to combat climate change and its impacts by reducing campus carbon outputs and increasing composting.",
    color: "#3F7E44",
    activeProjects: 15,
    impactCount: 16400,
    studentContributors: 1250,
    awarenessCampaigns: 8,
    caseStudies: [
      {
        id: "cs-13-1",
        title: "City Canopy Reforestation",
        location: "Metropolis High District",
        year: 2025,
        outcome: "Planted 2,500 native saplings in urban heat islands, calculated to sequester 75 tons of CO2 annually.",
        description: "Engaged 400 local high school and middle school youth volunteers on Earth Day."
      },
      {
        id: "cs-13-2",
        title: "Zero Waste Food Composting Network",
        location: "District School Cafeterias",
        year: 2025,
        outcome: "Diverted 18 tons of organic waste from municipal landfills, transforming it into agricultural loam.",
        description: "Youth-led waste separation campaign and manual compost drum rotation oversight."
      }
    ],
    activities: [
      {
        id: "act-13-1",
        title: "Global Warmings - Student Walkout and Poster Campaign",
        date: "2026-06-22",
        location: "Central Civic Plaza",
        category: "awareness",
        registeredStudents: 412
      },
      {
        id: "act-13-2",
        title: "Tree Planting Extravaganza",
        date: "2026-07-15",
        location: "Greenbelt Eco-Reserve",
        category: "volunteer",
        registeredStudents: 220
      }
    ]
  },
  {
    id: 14,
    code: "SDG 14",
    name: "Life Below Water",
    description: "Conserve and sustainably use the oceans, seas and marine resources for sustainable development.",
    color: "#0A97D9",
    activeProjects: 4,
    impactCount: 3100,
    studentContributors: 198,
    awarenessCampaigns: 2,
    caseStudies: [
      {
        id: "cs-14-1",
        title: "Artificial Coral Reef Sinking Project",
        location: "Coastal Reef Barrier",
        year: 2024,
        outcome: "Placed 30 bio-compatible structural dome clusters resulting in 200% increment of fish variety in 12 months.",
        description: "Marine biology students assisted with remote underwater camera tracking and health charting."
      }
    ],
    activities: [
      {
        id: "act-14-1",
        title: "Seashore Plastic Micro-audit",
        date: "2026-06-29",
        location: "North Coast Marine Area",
        category: "volunteer",
        registeredStudents: 48
      }
    ]
  },
  {
    id: 15,
    code: "SDG 15",
    name: "Life on Land",
    description: "Protect, restore and promote sustainable use of terrestrial ecosystems, sustainably manage forests, and halt biodiversity loss.",
    color: "#56C02B",
    activeProjects: 5,
    impactCount: 2900,
    studentContributors: 150,
    awarenessCampaigns: 3,
    caseStudies: [
      {
        id: "cs-15-1",
        title: "Pollinator Pathways and Bee Habitats",
        location: "Southend Parks",
        year: 2025,
        outcome: "Constructed 18 insect sanctuaries and planted 1.2 acres of wildflower meadows boosting bee counts by 45%.",
        description: "A collaborative community flora restoration designed by youth ecological teams."
      }
    ],
    activities: [
      {
        id: "act-15-1",
        title: "Deforestation Awareness Webinar",
        date: "2026-06-11",
        location: "Virtual - Zoom Broadcast",
        category: "awareness",
        registeredStudents: 98
      }
    ]
  }
];

export const initialPartners: Partner[] = [
  {
    id: "p-1",
    name: "Oakridge Science High School",
    category: "school",
    logoUrl: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=120&auto=format&fit=crop&q=80",
    verified: true,
    website: "https://oakridge.edu",
    contactEmail: "sdg-coordinator@oakridge.edu",
    visibility: true,
    registeredAt: "2025-01-15",
    activeSDGs: [3, 4, 13],
    bio: "A premier public science high school dedicated to equipping tomorrow's leaders with practical sustainability, engineering literacy, and global civic consciousness."
  },
  {
    id: "p-2",
    name: "Green Horizon alliance",
    category: "ngo",
    logoUrl: "https://images.unsplash.com/photo-1509099836639-18ba1795216d?w=120&auto=format&fit=crop&q=80",
    verified: true,
    website: "https://greenhorizon.org",
    contactEmail: "partnerships@greenhorizon.org",
    visibility: true,
    registeredAt: "2025-03-22",
    activeSDGs: [6, 7, 13, 15],
    bio: "Global NGO advancing ecological conservation, clean electricity scaling, and biodiversity stewardship through community-driven youth action leagues."
  },
  {
    id: "p-3",
    name: "Solaris Global Renewables",
    category: "company",
    logoUrl: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=120&auto=format&fit=crop&q=80",
    verified: true,
    website: "https://solaris-renewables.com",
    contactEmail: "impact@solaris-renewables.com",
    visibility: true,
    registeredAt: "2025-11-04",
    activeSDGs: [7, 13],
    bio: "Leading renewable energy enterprise developing smart solar infrastructure and offering technology grants, internships, and educational supplies to partner schools."
  },
  {
    id: "p-4",
    name: "Youth Empowerment Initiative",
    category: "ngo",
    logoUrl: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=120&auto=format&fit=crop&q=80",
    verified: false,
    website: "https://youthempower.net",
    contactEmail: "admin@youthempower.net",
    visibility: false,
    registeredAt: "2026-05-30",
    activeSDGs: [4, 5],
    bio: "Grassroots organization providing career mentorship, leadership incubators, and civic advocacy seminars for underprivileged teenage girls."
  }
];

export const initialReviewRequests: ReviewRequest[] = [
  {
    id: "req-1",
    partnerName: "Apex Eco-Logistics Corp",
    category: "company",
    logoUrl: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=120&auto=format&fit=crop&q=80",
    status: "pending",
    requestedAt: "2026-06-08",
    email: "sustainability@apex-logistics.com",
    website: "https://apex-logistics.com/green",
    details: "Apex wishes to sponsor 12 school-level carbon tracking dashboards and audit all logistical routes to optimize student transport carbon output.",
    documents: [
      { label: "Business Registration Profile", url: "#", verified: true },
      { label: "Corporate Sustainability Policy Statement", url: "#", verified: false },
      { label: "Annual CSR Capital Guarantee Letter", url: "#", verified: true }
    ],
    appliedSDGs: [7, 13]
  },
  {
    id: "req-2",
    partnerName: "Riverdale Eco-Secondary School",
    category: "school",
    logoUrl: "https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=120&auto=format&fit=crop&q=80",
    status: "pending",
    requestedAt: "2026-06-10",
    email: "principal@riverdale.edu",
    website: "https://riverdale-eco.edu",
    details: "Seeking to register 1,200 students onto the StepUp portal to log their composting, stream clean-ups, and energy-conserving audits.",
    documents: [
      { label: "School Board Resolution Copy", url: "#", verified: true },
      { label: "Lead SDG Coordinator Credentials", url: "#", verified: true }
    ],
    appliedSDGs: [4, 6, 13, 15]
  },
  {
    id: "req-3",
    partnerName: "Save the Oceans Project",
    category: "ngo",
    logoUrl: "https://images.unsplash.com/photo-1484821549836-7077bef59775?w=120&auto=format&fit=crop&q=80",
    status: "approved",
    requestedAt: "2026-05-12",
    email: "alliances@saveoceans.org",
    website: "https://saveoceans.org",
    details: "Advocate team of coastal engineers and divers organizing plastic interception tasks. Certified and verified.",
    remarks: "Excellent track record with micro-plastics interception. NGO registration verified with the State Registry of Charities.",
    documents: [
      { label: "Charitable Trust Charter", url: "#", verified: true },
      { label: "Coastal Permit Approvals", url: "#", verified: true }
    ],
    appliedSDGs: [14]
  }
];

export const initialInquiries: InquiryMessage[] = [
  {
    id: "msg-1",
    senderName: "Dr. Sarah Hamilton",
    senderEmail: "s.hamilton@sciencedistrict.edu",
    subject: "Collaboration Request: Joint SDG Youth Hackathon",
    message: "Greetings, We are hoping to organize a multi-school hackathon focused on SDG 13 (Climate Action) and SDG 7 (Affordable Energy) this coming September. We would love to host registration through the StepUp portal and let students receive digital credentials. Can we arrange a brief call next Tuesday?",
    date: "2026-06-10T14:32:00Z",
    category: "partnership",
    status: "unread",
    history: []
  },
  {
    id: "msg-2",
    senderName: "Marcus Vance",
    senderEmail: "marcus.vance@nexawater.com",
    subject: "Submitting safe water metrics for SDG 6 dashboard",
    message: "Hi Admin, I represented NexaWater in our joint Rajasthan solar pump project. I wanted to ask how we can upload the real-time gallon metrics from April so that it shows on the county-wide impact statistics widget. Thank you!",
    date: "2026-06-09T09:15:00Z",
    category: "sdg",
    status: "read",
    history: [
      {
        sender: "visitor",
        message: "Hi Admin, I represented NexaWater in our joint Rajasthan solar pump project. I wanted to ask how we can upload the real-time gallon metrics from April so that it shows on the county-wide impact statistics widget.",
        timestamp: "2026-06-09T09:15:00Z"
      }
    ]
  },
  {
    id: "msg-3",
    senderName: "Claire Dupont",
    senderEmail: "claire.dupont@greenworld.fr",
    subject: "Feedback on the partner registration flow",
    message: "Great system overall! We just finished registering. There was a small typo in the PDF document guidelines on the second page (referred as 2024 guidelines instead of 2026). Otherwise, the portal is beautiful and fast to use.",
    date: "2026-06-05T16:45:00Z",
    category: "feedback",
    status: "replied",
    history: [
      {
        sender: "visitor",
        message: "Great system overall! We just finished registering. There was a small typo in the PDF document guidelines on the second page (referred as 2024 guidelines instead of 2026). Otherwise, the portal is beautiful and fast to use.",
        timestamp: "2026-06-05T16:45:00Z"
      },
      {
        sender: "admin",
        message: "Thank you so much for the helpful feedback, Claire! We have successfully updated the PDF copy text to reference the latest 2026 guidelines. Hope your youth programs are off to a stellar start!",
        timestamp: "2026-06-06T10:00:00Z"
      }
    ]
  },
  {
    id: "msg-4",
    senderName: "Jason Vance",
    senderEmail: "jason@highlands-academy.org",
    subject: "Lost activation credential for school profile",
    message: "Help! Our high school registered last week but our lead environmental teacher deleted the confirmation activation token email. Can you please resend the admin token for Highlands Academy?",
    date: "2026-06-11T07:22:00Z",
    category: "general",
    status: "unread",
    history: []
  }
];
